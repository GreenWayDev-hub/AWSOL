! function(e) {
    function t(o) {
        if (n[o]) return n[o].exports;
        var i = n[o] = {
            exports: {},
            id: o,
            loaded: !1
        };
        return e[o].call(i.exports, i, i.exports, t), i.loaded = !0, i.exports
    }
    var n = {};
    return t.m = e, t.c = n, t.p = "", t(0)
}([function(e, t, n) {
    n(1), n(3), n(25), e.exports = n(27)
}, function(e, t, n) {
    var o = n(2);
    Y.use("node", function(e) {
        window.Singleton.create({
            ready: function() {
                if (e.one(".collection-type-index")) {
                    if (window.innerWidth <= 640) return !1;
                    this.initializer(), this.bindUI(), this.syncUI()
                }
            },
            initializer: function() {
                this.navShowPosition = 0, this.el = e.one(".show-on-scroll"), this.initElOffset()
            },
            initElOffset: function() {
                return this.el ? (this.elOffset = e.one(this.el.getData("offset-el")), this.offsetBehavior = this.el.getData("offset-behavior") || "top", this.elOffset ? (e.one("body").prepend(e.Node.create('<div class="show-on-scroll-wrapper" id="showOnScrollWrapper"></div>')), this.wrapper = e.one("#showOnScrollWrapper"), this.wrapper.setHTML(this.el._node.outerHTML), void 0) : void console.warn("No show on scroll offset element found.")) : void console.warn("No show on scroll element found.")
            },
            bindUI: function() {
                this.scrollEvents(), e.one(window).on("resize", function() {
                    this.syncUI()
                }, this)
            },
            syncUI: function() {
                this.getVariables()
            },
            getVariables: function() {
                (this.elOffset || (this.initElOffset(), this.elOffset)) && ("bottom" === this.offsetBehavior ? this.navShowPosition = this.elOffset.getY() + this.elOffset.get("offsetHeight") : this.navShowPosition = this.elOffset.getY())
            },
            scrollEvents: function() {
                this.scrolling = !1, e.one(window).on("scroll", function() {
                    this.scrolling === !1 && (this.scrolling = !0, this.scrollLogic(), o(function() {
                        this.scrolling = !1
                    }, 300, this))
                }, this)
            },
            scrollLogic: function() {
                window.pageYOffset > this.navShowPosition ? this.wrapper.addClass("show") : this.wrapper.removeClass("show"), e.later(100, this, function() {
                    this.scrolling === !0 && window.requestAnimationFrame(e.bind(function() {
                        this.scrollLogic()
                    }, this))
                })
            }
        })
    })
}, function(e, t) {
    function n(e, t, n) {
        t = t || 100, n = n || window, e && (o && o.cancel(), o = Y.later(t, n, e))
    }
    var o;
    e.exports = n
}, function(e, t, n) {
    var o = n(4),
        i = n(2),
        r = n(5);
    Y.use(["node", "squarespace-gallery-ng"], function(e) {
        window.Singleton.create({
            ready: function() {
                this.resetGalleryPosition(), e.one(".collection-type-index") && this.resetIndexGalleryPosition(), e.one(".collection-type-blog.view-list .sqs-featured-posts-gallery") && e.one("body").addClass("has-banner-image"), this.init(), this.bindUI(), this.syncUI()
            },
            init: function() {
                if (this.setupUserAccountLinks(), this.forceMobileNav(), this.promotedGalleryShrink(), e.one(".has-promoted-gallery") ? (this.textShrink(".meta-description p > strong", "p"), this.textShrink(".meta-description p > em > strong", "p")) : (this.textShrink(".desc-wrapper p > strong", "p"), this.textShrink(".desc-wrapper p > em > strong", "p")), this.textShrink(".post-title a", ".post-title"), this.textShrink(".blog-item-wrapper .post-title", ".title-desc-wrapper"), this._touch = e.one(".touch-styles"), e.one(".collection-type-blog.view-list .sqs-featured-posts-gallery") && this.makeFeaturedGallery(".posts", ".post"), this.hideArrowsWhenOneSlide(), this.repositionCartButton(), !this._touch) {
                    var t = e.one("#preFooter");
                    t.inViewportRegion() === !1 && t.addClass("unscrolled"), e.one(window).on("scroll", function() {
                        t.hasClass("unscrolled") && t.toggleClass("unscrolled", !t.inViewportRegion())
                    })
                }
                var n = Array.prototype.slice.call(document.body.querySelectorAll("div.sqs-video-background"));
                n.forEach(function(e) {
                    r(e.parentNode)
                })
            },
            setupUserAccountLinks: function() {
                e.all(".user-account-link").each(function(e) {
                    var t = o.isUserAuthenticated() ? ".unauth" : ".auth",
                        n = e.one(t);
                    n.remove(), e.on("click", function(e) {
                        e.preventDefault(), o.openAccountScreen()
                    })
                })
            },
            bindUI: function() {
                e.one(window).on("resize", this.syncUI, this), e.all(".mobile-nav-toggle, .body-overlay").each(function(t) {
                    t.on("click", function() {
                        e.one("body").toggleClass("mobile-nav-open")
                    })
                });
                var t = e.throttle(e.bind(function() {
                    this.bindScroll("#preFooter", .6 * e.one("#preFooter").height())
                }, this), 200);
                this._touch || e.one(window).on("scroll", t), e.all(".subnav").each(function(t) {
                    var n = t._node.getBoundingClientRect();
                    n.right > e.config.win.innerWidth && t.addClass("right")
                });
                var n = '#sidecarNav a[href^="#"], #sidecarNav a[href^="/#"], #sidecarNav a[href^="/"][href*="#"]';
                e.all(n).each(function(t) {
                    t.on("click", function(t) {
                        e.one("body").removeClass("mobile-nav-open")
                    }, this)
                }, this), this.showIndexNavOnScroll(), this.disableHoverOnScroll()
            },
            syncUI: function() {
                this.forceMobileNav(), i(function() {
                    this.addPaddingToFooter()
                }, 100, this)
            },
            bindScroll: function(t, n) {
                var o;
                if (o || (o = e.one(t + ".unscrolled")), o) {
                    var i = window.pageYOffset + e.one("body").get("winHeight"),
                        r = o.getY() + (n || 0);
                    i >= r && o.removeClass("unscrolled")
                }
            },
            _atLeast: 0,
            forceMobileNav: function() {
                var t = e.one("#mainNavWrapper");
                if (t) {
                    var n, o, i, r = e.one("body").get("winWidth"),
                        a = e.one("#header");
                    i = e.one("#logoWrapper") ? parseInt(e.Squarespace.Template.getTweakValue("logoContainerWidth"), 10) : parseInt(e.Squarespace.Template.getTweakValue("siteTitleContainerWidth"), 10), r > this._atLeast ? (e.one("body").removeClass("force-mobile-nav"), n = a.get("offsetWidth") - parseInt(a.getStyle("paddingLeft"), 10) - parseInt(a.getStyle("paddingRight"), 10), o = t.get("offsetWidth"), o > n - i && (e.one("body").addClass("force-mobile-nav"), this._atLeast = r)) : e.one("body").addClass("force-mobile-nav")
                }
            },
            makeFeaturedGallery: function(t, n) {
                new e.Squarespace.Gallery2({
                    autoHeight: !1,
                    container: t,
                    slides: n,
                    elements: {
                        next: ".next-slide, .simple .next, .sqs-gallery-controls .next",
                        previous: ".previous-slide, .simple .previous, .sqs-gallery-controls .previous",
                        controls: ".dots, .circles",
                        currentIndex: ".current-index",
                        totalSlides: ".total-slides"
                    },
                    loop: !0,
                    loaderOptions: {
                        load: !0
                    },
                    design: "stacked",
                    designOptions: {
                        transition: "fade",
                        clickBehavior: "auto"
                    },
                    refreshOnResize: !0
                })
            },
            promotedGalleryShrink: function() {
                var t, n, o, i = ".has-promoted-gallery #promotedGalleryWrapper .meta";
                e.one(i) && (t = e.one("#promotedGalleryWrapper").get("offsetHeight"), e.one(".transparent-header") && (t -= 90), e.all(i).each(function(e) {
                    e.setStyle("display", "block"), n = e.get("offsetHeight"), n > t && (o = e.ancestor(".slide"), o.addClass("reduce-text-size"), n = e.get("offsetHeight"), n > t && (o.removeClass("reduce-text-size"), o.addClass("hide-body-text"), n = e.get("offsetHeight"), n > t && o.addClass("reduce-text-size"))), e.setAttribute("style", "")
                }))
            },
            textShrink: function(t, n) {
                e.one(t) && e.one(t).ancestor(n) && e.all(t).each(function(t) {
                    t.plug(e.Squarespace.TextShrink, {
                        parentEl: t.ancestor(n)
                    })
                })
            },
            resetIndexGalleryPosition: function() {
                var t = ".collection-type-index .index-section .sqs-layout > .sqs-row:first-child > .sqs-col-12 > .gallery-block:first-child .sqs-gallery-block-slideshow",
                    n = ".collection-type-index .index-section .promoted-gallery-wrapper ~ .index-section-wrapper .sqs-layout > .sqs-row:first-child > .sqs-col-12 > .gallery-block:first-child",
                    o = e.one(".collection-type-index .index-section:first-child .sqs-layout > .sqs-row:first-child > .sqs-col-12 > .gallery-block:first-child .sqs-gallery-block-slideshow");
                o && e.one("body").addClass("has-banner-image"), e.one(t) && (e.one("body").addClass("has-promoted-gallery"), e.all(n).each(function(e) {
                    e.one(".sqs-gallery-block-slideshow") && e.ancestor(".index-section-wrapper").previous(".promoted-gallery-wrapper").addClass("promoted-full").append(e)
                }))
            },
            resetGalleryPosition: function() {
                var t = e.one(".collection-type-page .main-content .sqs-layout > .sqs-row:first-child > .sqs-col-12 > .gallery-block:first-child .sqs-gallery-block-slideshow"),
                    n = e.one(".collection-type-page .main-content .sqs-layout > .sqs-row:first-child > .sqs-col-12 > .gallery-block:first-child");
                t && (e.one("#promotedGalleryWrapper .row .col").append(n), e.one("body").addClass("has-promoted-gallery").addClass("has-banner-image"))
            },
            hideArrowsWhenOneSlide: function() {
                e.one(".posts .post:only-child") && e.all(".circles").addClass("hidden")
            },
            repositionCartButton: function() {
                var t = e.one("#header").get("offsetHeight"),
                    n = e.one(".sqs-cart-dropzone");
                n && (e.one(".transparent-header.has-banner-image") ? n.setStyle("top", t) : n.setStyle("top", t + 20))
            },
            showIndexNavOnScroll: function() {
                var t, n = function() {
                    if (e.one(".index-section")) {
                        var n = e.one(".index-section").getDOMNode();
                        t = n.getBoundingClientRect().bottom + window.pageYOffset
                    }
                };
                if (n(), e.one(".collection-type-index") && window.innerWidth <= 640) {
                    var o = function() {
                        t - window.pageYOffset <= 0 ? e.one("body").addClass("fix-header-nav") : e.one("body").removeClass("fix-header-nav")
                    };
                    e.one(window).on("resize", function() {
                        n()
                    }), o(), e.one(window).on("scroll", function() {
                        o()
                    }, this), e.one(".mobile-nav-toggle.fixed-nav-toggle").on("click", function() {
                        e.one("body").hasClass("fix-header-nav") && e.one("body").removeClass("fix-header-nav")
                    }), e.one(window).on(["touchstart", "MSPointerDown"], function() {
                        this._timeout && this._timeout.cancel(), this.isHidden = !0, this.isHidden === !0 && (e.one(".mobile-nav-toggle.fixed-nav-toggle").setStyle("opacity", 1), this.isHidden = !1)
                    }, this), e.one(window).on(["touchend", "MSPointerUp"], function() {
                        this._timeout = e.later(1500, this, function() {
                            this.isHidden = !0, e.one(".mobile-nav-toggle.fixed-nav-toggle").setStyle("opacity", 0)
                        })
                    }, this)
                }
            },
            addPaddingToFooter: function() {
                var t = parseInt(e.one("#footer").getStyle("paddingBottom"), 10),
                    n = e.one("#siteWrapper").get("offsetHeight"),
                    o = e.one("body").get("winHeight");
                n - t <= o && e.one("#footer").setStyle("paddingBottom", o - (n - t))
            },
            disableHoverOnScroll: function() {
                if (e.UA.mobile) return !1;
                var t, n = ".disable-hover:not(.sqs-layout-editing), .disable-hover:not(.sqs-layout-editing) * { pointer-events: none  ; }",
                    o = document.head || document.getElementsByTagName("head")[0],
                    i = document.createElement("style"),
                    r = document.body;
                i.type = "text/css", i.styleSheet ? i.styleSheet.cssText = n : i.appendChild(document.createTextNode(n)), o.appendChild(i), window.addEventListener("scroll", function() {
                    clearTimeout(t), r.classList.contains("disable-hover") || r.classList.add("disable-hover"), t = setTimeout(function() {
                        r.classList.remove("disable-hover")
                    }, 300)
                }, !1)
            }
        })
    })
}, function(e, t) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    /**
     * @license
     * Copyright 2016 Squarespace, INC.
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *    http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    var n = "UserAccounts API not available",
        o = window.UserAccountApi,
        i = function() {
            console.warn(n)
        },
        r = o ? o.isUserAuthenticated : i,
        a = o ? o.openAccountScreen : i;
    t.default = {
        isUserAuthenticated: r,
        openAccountScreen: a
    }, e.exports = t.default
}, function(e, t, n) {
    "use strict";

    function o(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function i(e, t) {
        var n = e.querySelector(".sqs-video-background"),
            o = (0, s.default)(n),
            i = new r.VideoBackground(o),
            a = function() {
                i.scaleVideo()
            },
            l = function() {
                i.destroy(), i = new r.VideoBackground(o)
            };
        return "function" == typeof t && t({
            handleResize: a,
            handleTweak: l
        }), {
            destroy: function() {
                i.destroy()
            }
        }
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var r = n(6),
        a = n(24),
        s = o(a);
    t.default = i, e.exports = t.default
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.videoAutoplayTest = t.VideoFilterPropertyValues = t.VideoBackground = void 0, n(7);
    var o = n(8);
    t.VideoBackground = o.VideoBackground, t.VideoFilterPropertyValues = o.VideoFilterPropertyValues, t.videoAutoplayTest = o.videoAutoplayTest
}, function(e, t) {
    ! function() {
        function e(e, t) {
            t = t || {
                bubbles: !1,
                cancelable: !1,
                detail: void 0
            };
            var n = document.createEvent("CustomEvent");
            return n.initCustomEvent(e, t.bubbles, t.cancelable, t.detail), n
        }
        return "function" != typeof window.CustomEvent && (e.prototype = window.Event.prototype, void(window.CustomEvent = e))
    }()
}, function(e, t, n) {
    "use strict";

    function o(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.videoAutoplayTest = t.VideoFilterPropertyValues = t.VideoBackground = void 0;
    var i = n(9),
        r = o(i),
        a = n(23),
        s = n(12),
        l = o(s);
    t.VideoBackground = r.default, t.VideoFilterPropertyValues = a.filterProperties, t.videoAutoplayTest = l.default
}, function(e, t, n) {
    "use strict";

    function o(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function i(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var r = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var o = t[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, o.key, o)
                }
            }
            return function(t, n, o) {
                return n && e(t.prototype, n), o && e(t, o), t
            }
        }(),
        a = n(10),
        s = o(a),
        l = n(12),
        c = o(l),
        u = n(14),
        d = n(22),
        A = n(16),
        f = n(23),
        h = n(15),
        p = {
            vimeo: {
                api: u.initializeVimeoAPI,
                player: u.initializeVimeoPlayer
            },
            youtube: {
                api: d.initializeYouTubeAPI,
                player: d.initializeYouTubePlayer
            }
        },
        g = function() {
            function e(t) {
                var n = this,
                    o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : window;
                i(this, e), this.windowContext = o, this.events = [], this.browserCanAutoPlay = !1, this.videoCanAutoPlay = !1, this.setInstanceProperties(t), this.renderFallbackBehavior(), (0, c.default)().then(function(e) {
                    n.logger(e), n.browserCanAutoPlay = !0, n.initializeVideoAPI()
                }, function(e) {
                    n.logger(e), n.browserCanAutoPlay = !1
                }).then(function() {
                    n.setDisplayEffects(), n.bindUI(), n.DEBUG.enabled === !0 && (window.vdbg = n)
                })
            }
            return r(e, [{
                key: "destroy",
                value: function() {
                    this.events && this.events.forEach(function(e) {
                        return e.target.removeEventListener(e.type, e.handler, !0)
                    }), this.events = null, this.player && "function" == typeof this.player.destroy && (this.player.iframe && this.player.iframe.classList.remove("ready"), this.player.destroy(), this.player = {}), "number" == typeof this.timer && (clearTimeout(this.timer), this.timer = null)
                }
            }, {
                key: "bindUI",
                value: function() {
                    var e = this,
                        t = function() {
                            e.windowContext.requestAnimationFrame(function() {
                                e.scaleVideo()
                            })
                        };
                    this.events.push({
                        target: this.windowContext,
                        type: "resize",
                        handler: t
                    }), this.windowContext.addEventListener("resize", t, !0)
                }
            }, {
                key: "setInstanceProperties",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return e = (0, s.default)({}, A.DEFAULT_PROPERTY_VALUES, e), 1 === e.container.nodeType ? this.container = e.container : "string" == typeof e.container && (this.container = document.querySelector(e.container)), this.container ? (this.videoSource = (0, h.getVideoSource)(e.url), this.videoId = (0, h.getVideoID)(e.url, this.videoSource), this.customFallbackImage = (0, h.validatedImage)(e.customFallbackImage || e.container.querySelector("img")), this.filter = e.filter, this.filterStrength = e.filterStrength, this.fitMode = e.fitMode, this.scaleFactor = e.scaleFactor, this.playbackSpeed = parseFloat(e.playbackSpeed) < .5 ? 1 : parseFloat(e.playbackSpeed), this.timeCode = {
                        start: (0, h.getStartTime)(e.url, this.videoSource) || e.timeCode.start,
                        end: e.timeCode.end
                    }, this.player = {}, void(this.DEBUG = e.DEBUG)) : (console.error("Container " + e.container + " not found"), !1)
                }
            }, {
                key: "onFallbackImageLoaded",
                value: function() {
                    this.customFallbackImage.classList.add("loaded")
                }
            }, {
                key: "setFallbackImage",
                value: function() {
                    var e = this,
                        t = this.customFallbackImage;
                    if (t) return t.hasAttribute("src") && t.complete ? void this.onFallbackImageLoaded() : (t.addEventListener("load", function() {
                        e.onFallbackImageLoaded()
                    }, {
                        once: !0
                    }), this.windowContext.ImageLoader ? void this.windowContext.ImageLoader.load(t, {
                        load: !0
                    }) : void(t.src = t.src))
                }
            }, {
                key: "initializeVideoAPI",
                value: function() {
                    var e = this;
                    if (this.browserCanAutoPlay && this.videoSource && this.videoId) {
                        this.player.ready = !1;
                        var t = p[this.videoSource].api,
                            n = t(this.windowContext);
                        n.then(function(t) {
                            e.logger(t), e.player.ready = !1, e.initializeVideoPlayer()
                        }).catch(function(t) {
                            document.body.classList.add("ready"), e.logger(t)
                        })
                    } else document.body.classList.add("ready")
                }
            }, {
                key: "initializeVideoPlayer",
                value: function() {
                    var e = this;
                    if (this.player.ready) {
                        try {
                            this.player.destroy()
                        } catch (e) {}
                        this.player.ready = !1
                    }
                    var t = p[this.videoSource].player,
                        n = t({
                            instance: this,
                            container: this.container,
                            win: this.windowContext,
                            videoId: this.videoId,
                            startTime: this.timeCode.start,
                            speed: this.playbackSpeed,
                            readyCallback: function() {
                                e.player.iframe.classList.add("background-video"), e.videoAspectRatio = (0, h.findPlayerAspectRatio)(e.container, e.player, e.videoSource), e.syncPlayer();
                                var t = new CustomEvent("ready");
                                e.container.dispatchEvent(t)
                            },
                            stateChangeCallback: function(t, n) {
                                switch (t) {
                                    case "playing":
                                        e.videoCanAutoPlay || (e.logger("video started playing"), e.videoCanAutoPlay = !0, e.player.ready = !0, e.player.iframe.classList.add("ready"), e.container.classList.remove("mobile"))
                                }
                                t && e.logger(t), n && e.logger(n)
                            }
                        });
                    n.then(function(t) {
                        e.player = t
                    }, function(t) {
                        e.logger(t)
                    })
                }
            }, {
                key: "renderFallbackBehavior",
                value: function() {
                    this.setFallbackImage(), this.container.classList.add("mobile"), this.logger("added mobile")
                }
            }, {
                key: "syncPlayer",
                value: function() {
                    this.setDisplayEffects(), this.setSpeed(), this.scaleVideo()
                }
            }, {
                key: "scaleVideo",
                value: function(e) {
                    this.setFallbackImage();
                    var t = this.player.iframe;
                    if (t) {
                        var n = e || this.scaleFactor;
                        if ("fill" !== this.fitMode) return t.style.width = "", void(t.style.height = "");
                        var o = t.parentNode.clientWidth,
                            i = t.parentNode.clientHeight,
                            r = o / i,
                            a = 0,
                            s = 0;
                        r > this.videoAspectRatio ? (a = o * n, s = o * n / this.videoAspectRatio) : this.videoAspectRatio > r ? (a = i * n * this.videoAspectRatio, s = i * n) : (a = o * n, s = i * n), t.style.width = a + "px", t.style.height = s + "px", t.style.left = 0 - (a - o) / 2 + "px", t.style.top = 0 - (s - i) / 2 + "px"
                    }
                }
            }, {
                key: "setSpeed",
                value: function(e) {
                    this.playbackSpeed = parseFloat(this.playbackSpeed), this.player.setPlaybackRate && this.player.setPlaybackRate(this.playbackSpeed)
                }
            }, {
                key: "setDisplayEffects",
                value: function() {
                    this.setFilter()
                }
            }, {
                key: "setFilter",
                value: function() {
                    var e = this.container.style,
                        t = f.filterOptions[this.filter - 1],
                        n = "";
                    "none" !== t && (n = this.getFilterStyle(t, this.filterStrength));
                    var o = "blur" === t;
                    e.webkitFilter = o ? "" : n, e.filter = o ? "" : n, this.container.classList.toggle("filter-blur", o), Array.prototype.slice.call(this.container.children).forEach(function(e) {
                        e.style.webkitFilter = o ? n : "", e.style.filter = o ? n : ""
                    })
                }
            }, {
                key: "getFilterStyle",
                value: function(e, t) {
                    return e + "(" + (f.filterProperties[e].modifier(t) + f.filterProperties[e].unit) + ")"
                }
            }, {
                key: "logger",
                value: function(e) {
                    this.DEBUG.enabled && this.DEBUG.verbose && this.windowContext.console.log(e)
                }
            }]), e
        }();
    t.default = g
}, function(e, t, n) {
    (function(e, n) {
        function o(e, t, n) {
            switch (n.length) {
                case 0:
                    return e.call(t);
                case 1:
                    return e.call(t, n[0]);
                case 2:
                    return e.call(t, n[0], n[1]);
                case 3:
                    return e.call(t, n[0], n[1], n[2])
            }
            return e.apply(t, n)
        }

        function i(e, t) {
            for (var n = -1, o = Array(e); ++n < e;) o[n] = t(n);
            return o
        }

        function r(e) {
            return function(t) {
                return e(t)
            }
        }

        function a(e, t) {
            return null == e ? void 0 : e[t]
        }

        function s(e, t) {
            return function(n) {
                return e(t(n))
            }
        }

        function l(e) {
            var t = -1,
                n = null == e ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }

        function c() {
            this.__data__ = Lt ? Lt(null) : {}, this.size = 0
        }

        function u(e) {
            var t = this.has(e) && delete this.__data__[e];
            return this.size -= t ? 1 : 0, t
        }

        function d(e) {
            var t = this.__data__;
            if (Lt) {
                var n = t[e];
                return n === xe ? void 0 : n
            }
            return kt.call(t, e) ? t[e] : void 0
        }

        function A(e) {
            var t = this.__data__;
            return Lt ? void 0 !== t[e] : kt.call(t, e)
        }

        function f(e, t) {
            var n = this.__data__;
            return this.size += this.has(e) ? 0 : 1, n[e] = Lt && void 0 === t ? xe : t, this
        }

        function h(e) {
            var t = -1,
                n = null == e ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }

        function p() {
            this.__data__ = [], this.size = 0
        }

        function g(e) {
            var t = this.__data__,
                n = Y(t, e);
            if (n < 0) return !1;
            var o = t.length - 1;
            return n == o ? t.pop() : jt.call(t, n, 1), --this.size, !0
        }

        function y(e) {
            var t = this.__data__,
                n = Y(t, e);
            return n < 0 ? void 0 : t[n][1]
        }

        function v(e) {
            return Y(this.__data__, e) > -1
        }

        function m(e, t) {
            var n = this.__data__,
                o = Y(n, e);
            return o < 0 ? (++this.size, n.push([e, t])) : n[o][1] = t, this
        }

        function b(e) {
            var t = -1,
                n = null == e ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }

        function w() {
            this.size = 0, this.__data__ = {
                hash: new l,
                map: new(Dt || h),
                string: new l
            }
        }

        function E(e) {
            var t = K(this, e).delete(e);
            return this.size -= t ? 1 : 0, t
        }

        function _(e) {
            return K(this, e).get(e)
        }

        function k(e) {
            return K(this, e).has(e)
        }

        function S(e, t) {
            var n = K(this, e),
                o = n.size;
            return n.set(e, t), this.size += n.size == o ? 0 : 1, this
        }

        function T(e) {
            var t = this.__data__ = new h(e);
            this.size = t.size
        }

        function x() {
            this.__data__ = new h, this.size = 0
        }

        function P(e) {
            var t = this.__data__,
                n = t.delete(e);
            return this.size = t.size, n
        }

        function R(e) {
            return this.__data__.get(e)
        }

        function I(e) {
            return this.__data__.has(e)
        }

        function F(e, t) {
            var n = this.__data__;
            if (n instanceof h) {
                var o = n.__data__;
                if (!Dt || o.length < Te - 1) return o.push([e, t]), this.size = ++n.size, this;
                n = this.__data__ = new b(o)
            }
            return n.set(e, t), this.size = n.size, this
        }

        function C(e, t) {
            var n = qt(e),
                o = !n && Wt(e),
                r = !n && !o && Jt(e),
                a = !n && !o && !r && Xt(e),
                s = n || o || r || a,
                l = s ? i(e.length, String) : [],
                c = l.length;
            for (var u in e) !t && !kt.call(e, u) || s && ("length" == u || r && ("offset" == u || "parent" == u) || a && ("buffer" == u || "byteLength" == u || "byteOffset" == u) || ne(u, c)) || l.push(u);
            return l
        }

        function V(e, t, n) {
            (void 0 === n || fe(e[t], n)) && (void 0 !== n || t in e) || j(e, t, n)
        }

        function B(e, t, n) {
            var o = e[t];
            kt.call(e, t) && fe(o, n) && (void 0 !== n || t in e) || j(e, t, n)
        }

        function Y(e, t) {
            for (var n = e.length; n--;)
                if (fe(e[n][0], t)) return n;
            return -1
        }

        function j(e, t, n) {
            "__proto__" == t && Gt ? Gt(e, t, {
                configurable: !0,
                enumerable: !0,
                value: n,
                writable: !0
            }) : e[t] = n
        }

        function U(e) {
            return null == e ? void 0 === e ? He : Ne : Ut && Ut in Object(e) ? ee(e) : le(e)
        }

        function G(e) {
            return me(e) && U(e) == Fe
        }

        function O(e) {
            if (!ve(e) || re(e)) return !1;
            var t = ge(e) ? Pt : st;
            return t.test(Ae(e))
        }

        function M(e) {
            return me(e) && ye(e.length) && !!ct[U(e)]
        }

        function N(e) {
            if (!ve(e)) return se(e);
            var t = ae(e),
                n = [];
            for (var o in e)("constructor" != o || !t && kt.call(e, o)) && n.push(o);
            return n
        }

        function D(e, t, n, o, i) {
            e !== t && Zt(t, function(r, a) {
                if (i || (i = new T), ve(r)) L(e, t, a, n, D, o, i);
                else {
                    var s = o ? o(ue(e, a), r, a + "", e, t, i) : void 0;
                    void 0 === s && (s = r), V(e, a, s)
                }
            }, Ee)
        }

        function L(e, t, n, o, i, r, a) {
            var s = ue(e, n),
                l = ue(t, n),
                c = a.get(l);
            if (c) return void V(e, n, c);
            var u = r ? r(s, l, n + "", e, t, a) : void 0,
                d = void 0 === u;
            if (d) {
                var A = qt(l),
                    f = !A && Jt(l),
                    h = !A && !f && Xt(l);
                u = l, A || f || h ? qt(s) ? u = s : pe(s) ? u = W(s) : f ? (d = !1, u = Z(l, !0)) : h ? (d = !1, u = H(l, !0)) : u = [] : be(l) || Wt(l) ? (u = s, Wt(s) ? u = we(s) : ve(s) && !ge(s) || (u = te(l))) : d = !1
            }
            d && (a.set(l, u), i(u, l, o, r, a), a.delete(l)), V(e, n, u)
        }

        function Q(e, t) {
            return Ht(ce(e, t, ke), e + "")
        }

        function Z(e, t) {
            if (t) return e.slice();
            var n = e.length,
                o = Ct ? Ct(n) : new e.constructor(n);
            return e.copy(o), o
        }

        function z(e) {
            var t = new e.constructor(e.byteLength);
            return new Ft(t).set(new Ft(e)), t
        }

        function H(e, t) {
            var n = t ? z(e.buffer) : e.buffer;
            return new e.constructor(n, e.byteOffset, e.length)
        }

        function W(e, t) {
            var n = -1,
                o = e.length;
            for (t || (t = Array(o)); ++n < o;) t[n] = e[n];
            return t
        }

        function q(e, t, n, o) {
            var i = !n;
            n || (n = {});
            for (var r = -1, a = t.length; ++r < a;) {
                var s = t[r],
                    l = o ? o(n[s], e[s], s, n, e) : void 0;
                void 0 === l && (l = e[s]), i ? j(n, s, l) : B(n, s, l)
            }
            return n
        }

        function J(e) {
            return Q(function(t, n) {
                var o = -1,
                    i = n.length,
                    r = i > 1 ? n[i - 1] : void 0,
                    a = i > 2 ? n[2] : void 0;
                for (r = e.length > 3 && "function" == typeof r ? (i--, r) : void 0, a && oe(n[0], n[1], a) && (r = i < 3 ? void 0 : r, i = 1), t = Object(t); ++o < i;) {
                    var s = n[o];
                    s && e(t, s, o, r)
                }
                return t
            })
        }

        function X(e) {
            return function(t, n, o) {
                for (var i = -1, r = Object(t), a = o(t), s = a.length; s--;) {
                    var l = a[e ? s : ++i];
                    if (n(r[l], l, r) === !1) break
                }
                return t
            }
        }

        function K(e, t) {
            var n = e.__data__;
            return ie(t) ? n["string" == typeof t ? "string" : "hash"] : n.map
        }

        function $(e, t) {
            var n = a(e, t);
            return O(n) ? n : void 0
        }

        function ee(e) {
            var t = kt.call(e, Ut),
                n = e[Ut];
            try {
                e[Ut] = void 0;
                var o = !0
            } catch (e) {}
            var i = Tt.call(e);
            return o && (t ? e[Ut] = n : delete e[Ut]), i
        }

        function te(e) {
            return "function" != typeof e.constructor || ae(e) ? {} : Qt(Vt(e))
        }

        function ne(e, t) {
            var n = typeof e;
            return t = null == t ? Ie : t, !!t && ("number" == n || "symbol" != n && lt.test(e)) && e > -1 && e % 1 == 0 && e < t
        }

        function oe(e, t, n) {
            if (!ve(n)) return !1;
            var o = typeof t;
            return !!("number" == o ? he(n) && ne(t, n.length) : "string" == o && t in n) && fe(n[t], e)
        }

        function ie(e) {
            var t = typeof e;
            return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e
        }

        function re(e) {
            return !!St && St in e
        }

        function ae(e) {
            var t = e && e.constructor,
                n = "function" == typeof t && t.prototype || wt;
            return e === n
        }

        function se(e) {
            var t = [];
            if (null != e)
                for (var n in Object(e)) t.push(n);
            return t
        }

        function le(e) {
            return Tt.call(e)
        }

        function ce(e, t, n) {
            return t = Mt(void 0 === t ? e.length - 1 : t, 0),
                function() {
                    for (var i = arguments, r = -1, a = Mt(i.length - t, 0), s = Array(a); ++r < a;) s[r] = i[t + r];
                    r = -1;
                    for (var l = Array(t + 1); ++r < t;) l[r] = i[r];
                    return l[t] = n(s), o(e, this, l)
                }
        }

        function ue(e, t) {
            if (("constructor" !== t || "function" != typeof e[t]) && "__proto__" != t) return e[t]
        }

        function de(e) {
            var t = 0,
                n = 0;
            return function() {
                var o = Nt(),
                    i = Re - (o - n);
                if (n = o, i > 0) {
                    if (++t >= Pe) return arguments[0]
                } else t = 0;
                return e.apply(void 0, arguments)
            }
        }

        function Ae(e) {
            if (null != e) {
                try {
                    return _t.call(e)
                } catch (e) {}
                try {
                    return e + ""
                } catch (e) {}
            }
            return ""
        }

        function fe(e, t) {
            return e === t || e !== e && t !== t
        }

        function he(e) {
            return null != e && ye(e.length) && !ge(e)
        }

        function pe(e) {
            return me(e) && he(e)
        }

        function ge(e) {
            if (!ve(e)) return !1;
            var t = U(e);
            return t == Ue || t == Ge || t == Ve || t == Le
        }

        function ye(e) {
            return "number" == typeof e && e > -1 && e % 1 == 0 && e <= Ie
        }

        function ve(e) {
            var t = typeof e;
            return null != e && ("object" == t || "function" == t)
        }

        function me(e) {
            return null != e && "object" == typeof e
        }

        function be(e) {
            if (!me(e) || U(e) != De) return !1;
            var t = Vt(e);
            if (null === t) return !0;
            var n = kt.call(t, "constructor") && t.constructor;
            return "function" == typeof n && n instanceof n && _t.call(n) == xt
        }

        function we(e) {
            return q(e, Ee(e))
        }

        function Ee(e) {
            return he(e) ? C(e, !0) : N(e)
        }

        function _e(e) {
            return function() {
                return e
            }
        }

        function ke(e) {
            return e
        }

        function Se() {
            return !1
        }
        var Te = 200,
            xe = "__lodash_hash_undefined__",
            Pe = 800,
            Re = 16,
            Ie = 9007199254740991,
            Fe = "[object Arguments]",
            Ce = "[object Array]",
            Ve = "[object AsyncFunction]",
            Be = "[object Boolean]",
            Ye = "[object Date]",
            je = "[object Error]",
            Ue = "[object Function]",
            Ge = "[object GeneratorFunction]",
            Oe = "[object Map]",
            Me = "[object Number]",
            Ne = "[object Null]",
            De = "[object Object]",
            Le = "[object Proxy]",
            Qe = "[object RegExp]",
            Ze = "[object Set]",
            ze = "[object String]",
            He = "[object Undefined]",
            We = "[object WeakMap]",
            qe = "[object ArrayBuffer]",
            Je = "[object DataView]",
            Xe = "[object Float32Array]",
            Ke = "[object Float64Array]",
            $e = "[object Int8Array]",
            et = "[object Int16Array]",
            tt = "[object Int32Array]",
            nt = "[object Uint8Array]",
            ot = "[object Uint8ClampedArray]",
            it = "[object Uint16Array]",
            rt = "[object Uint32Array]",
            at = /[\\^$.*+?()[\]{}|]/g,
            st = /^\[object .+?Constructor\]$/,
            lt = /^(?:0|[1-9]\d*)$/,
            ct = {};
        ct[Xe] = ct[Ke] = ct[$e] = ct[et] = ct[tt] = ct[nt] = ct[ot] = ct[it] = ct[rt] = !0, ct[Fe] = ct[Ce] = ct[qe] = ct[Be] = ct[Je] = ct[Ye] = ct[je] = ct[Ue] = ct[Oe] = ct[Me] = ct[De] = ct[Qe] = ct[Ze] = ct[ze] = ct[We] = !1;
        var ut = "object" == typeof e && e && e.Object === Object && e,
            dt = "object" == typeof self && self && self.Object === Object && self,
            At = ut || dt || Function("return this")(),
            ft = "object" == typeof t && t && !t.nodeType && t,
            ht = ft && "object" == typeof n && n && !n.nodeType && n,
            pt = ht && ht.exports === ft,
            gt = pt && ut.process,
            yt = function() {
                try {
                    var e = ht && ht.require && ht.require("util").types;
                    return e ? e : gt && gt.binding && gt.binding("util")
                } catch (e) {}
            }(),
            vt = yt && yt.isTypedArray,
            mt = Array.prototype,
            bt = Function.prototype,
            wt = Object.prototype,
            Et = At["__core-js_shared__"],
            _t = bt.toString,
            kt = wt.hasOwnProperty,
            St = function() {
                var e = /[^.]+$/.exec(Et && Et.keys && Et.keys.IE_PROTO || "");
                return e ? "Symbol(src)_1." + e : ""
            }(),
            Tt = wt.toString,
            xt = _t.call(Object),
            Pt = RegExp("^" + _t.call(kt).replace(at, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
            Rt = pt ? At.Buffer : void 0,
            It = At.Symbol,
            Ft = At.Uint8Array,
            Ct = Rt ? Rt.allocUnsafe : void 0,
            Vt = s(Object.getPrototypeOf, Object),
            Bt = Object.create,
            Yt = wt.propertyIsEnumerable,
            jt = mt.splice,
            Ut = It ? It.toStringTag : void 0,
            Gt = function() {
                try {
                    var e = $(Object, "defineProperty");
                    return e({}, "", {}), e
                } catch (e) {}
            }(),
            Ot = Rt ? Rt.isBuffer : void 0,
            Mt = Math.max,
            Nt = Date.now,
            Dt = $(At, "Map"),
            Lt = $(Object, "create"),
            Qt = function() {
                function e() {}
                return function(t) {
                    if (!ve(t)) return {};
                    if (Bt) return Bt(t);
                    e.prototype = t;
                    var n = new e;
                    return e.prototype = void 0, n
                }
            }();
        l.prototype.clear = c, l.prototype.delete = u, l.prototype.get = d, l.prototype.has = A, l.prototype.set = f, h.prototype.clear = p, h.prototype.delete = g, h.prototype.get = y, h.prototype.has = v, h.prototype.set = m, b.prototype.clear = w, b.prototype.delete = E, b.prototype.get = _, b.prototype.has = k, b.prototype.set = S, T.prototype.clear = x, T.prototype.delete = P, T.prototype.get = R, T.prototype.has = I, T.prototype.set = F;
        var Zt = X(),
            zt = Gt ? function(e, t) {
                return Gt(e, "toString", {
                    configurable: !0,
                    enumerable: !1,
                    value: _e(t),
                    writable: !0
                })
            } : ke,
            Ht = de(zt),
            Wt = G(function() {
                return arguments
            }()) ? G : function(e) {
                return me(e) && kt.call(e, "callee") && !Yt.call(e, "callee")
            },
            qt = Array.isArray,
            Jt = Ot || Se,
            Xt = vt ? r(vt) : M,
            Kt = J(function(e, t, n) {
                D(e, t, n)
            });
        n.exports = Kt
    }).call(t, function() {
        return this
    }(), n(11)(e))
}, function(e, t) {
    e.exports = function(e) {
        return e.webpackPolyfill || (e.deprecate = function() {}, e.paths = [], e.children = [], e.webpackPolyfill = 1), e
    }
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var o = !1,
        i = n(13),
        r = i.OggVideo,
        a = i.Mp4Video,
        s = function() {
            return new Promise(function(e, t) {
                if ("resolve" === o) return void e("resolved for debugging");
                if ("reject" === o) return void t("rejected for debugging");
                var n = document.createElement("video");
                n.autoplay = !0, n.setAttribute("autoplay", !0), n.muted = !0, n.setAttribute("muted", !0), n.playsinline = !0, n.setAttribute("playsinline", !0), n.volume = 0, n.setAttribute("data-is-playing", "false"), n.setAttribute("style", "width: 1px; height: 1px; position: fixed; top: 0; left: 0; z-index: 100;"), document.body.appendChild(n);
                var i = null,
                    s = function() {
                        i && (clearTimeout(i), i = null);
                        try {
                            document.body.removeChild(n)
                        } catch (e) {
                            return
                        }
                    };
                try {
                    if (n.canPlayType('video/ogg; codecs="theora"').match(/^(probably)|(maybe)/)) n.src = r;
                    else {
                        if (!n.canPlayType('video/mp4; codecs="avc1.42E01E"').match(/^(probably)|(maybe)/)) return s(), void t("no autoplay: element does not support mp4 or ogg format");
                        n.src = a
                    }
                } catch (e) {
                    return s(), void t("no autoplay: " + e)
                }
                n.addEventListener("play", function() {
                    n.setAttribute("data-is-playing", "true"), i = setTimeout(function() {
                        s(), t("no autoplay: unsure")
                    }, 3e3)
                }), n.addEventListener("canplay", function() {
                    return "true" === n.getAttribute("data-is-playing") ? (s(), e("autoplay supported"), !0) : (s(), t("no autoplay: browser does not support autoplay"), !1)
                }), n.load(), n.play()
            })
        };
    t.default = s
}, function(e, t) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = "data:video/ogg;base64,T2dnUwACAAAAAAAAAABmnCATAAAAAHDEixYBKoB0aGVvcmEDAgEAAQABAAAQAAAQAAAAAAAFAAAAAQAAAAAAAAAAAGIAYE9nZ1MAAAAAAAAAAAAAZpwgEwEAAAACrA7TDlj///////////////+QgXRoZW9yYSsAAABYaXBoLk9yZyBsaWJ0aGVvcmEgMS4xIDIwMDkwODIyIChUaHVzbmVsZGEpAQAAABoAAABFTkNPREVSPWZmbXBlZzJ0aGVvcmEtMC4yOYJ0aGVvcmG+zSj3uc1rGLWpSUoQc5zmMYxSlKQhCDGMYhCEIQhAAAAAAAAAAAAAEW2uU2eSyPxWEvx4OVts5ir1aKtUKBMpJFoQ/nk5m41mUwl4slUpk4kkghkIfDwdjgajQYC8VioUCQRiIQh8PBwMhgLBQIg4FRba5TZ5LI/FYS/Hg5W2zmKvVoq1QoEykkWhD+eTmbjWZTCXiyVSmTiSSCGQh8PB2OBqNBgLxWKhQJBGIhCHw8HAyGAsFAiDgUCw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDw8PDAwPEhQUFQ0NDhESFRUUDg4PEhQVFRUOEBETFBUVFRARFBUVFRUVEhMUFRUVFRUUFRUVFRUVFRUVFRUVFRUVEAwLEBQZGxwNDQ4SFRwcGw4NEBQZHBwcDhATFhsdHRwRExkcHB4eHRQYGxwdHh4dGxwdHR4eHh4dHR0dHh4eHRALChAYKDM9DAwOExo6PDcODRAYKDlFOA4RFh0zV1A+EhYlOkRtZ00YIzdAUWhxXDFATldneXhlSFxfYnBkZ2MTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTEhIVGRoaGhoSFBYaGhoaGhUWGRoaGhoaGRoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhoaGhESFh8kJCQkEhQYIiQkJCQWGCEkJCQkJB8iJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQREhgvY2NjYxIVGkJjY2NjGBo4Y2NjY2MvQmNjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRUVFRISEhUXGBkbEhIVFxgZGxwSFRcYGRscHRUXGBkbHB0dFxgZGxwdHR0YGRscHR0dHhkbHB0dHR4eGxwdHR0eHh4REREUFxocIBERFBcaHCAiERQXGhwgIiUUFxocICIlJRcaHCAiJSUlGhwgIiUlJSkcICIlJSUpKiAiJSUlKSoqEBAQFBgcICgQEBQYHCAoMBAUGBwgKDBAFBgcICgwQEAYHCAoMEBAQBwgKDBAQEBgICgwQEBAYIAoMEBAQGCAgAfF5cdH1e3Ow/L66wGmYnfIUbwdUTe3LMRbqON8B+5RJEvcGxkvrVUjTMrsXYhAnIwe0dTJfOYbWrDYyqUrz7dw/JO4hpmV2LsQQvkUeGq1BsZLx+cu5iV0e0eScJ91VIQYrmqfdVSK7GgjOU0oPaPOu5IcDK1mNvnD+K8LwS87f8Jx2mHtHnUkTGAurWZlNQa74ZLSFH9oF6FPGxzLsjQO5Qe0edcpttd7BXBSqMCL4k/4tFrHIPuEQ7m1/uIWkbDMWVoDdOSuRQ9286kvVUlQjzOE6VrNguN4oRXYGkgcnih7t13/9kxvLYKQezwLTrO44sVmMPgMqORo1E0sm1/9SludkcWHwfJwTSybR4LeAz6ugWVgRaY8mV/9SluQmtHrzsBtRF/wPY+X0JuYTs+ltgrXAmlk10xQHmTu9VSIAk1+vcvU4ml2oNzrNhEtQ3CysNP8UeR35wqpKUBdGdZMSjX4WVi8nJpdpHnbhzEIdx7mwf6W1FKAiucMXrWUWVjyRf23chNtR9mIzDoT/6ZLYailAjhFlZuvPtSeZ+2oREubDoWmT3TguY+JHPdRVSLKxfKH3vgNqJ/9emeEYikGXDFNzaLjvTeGAL61mogOoeG3y6oU4rW55ydoj0lUTSR/mmRhPmF86uwIfzp3FtiufQCmppaHDlGE0r2iTzXIw3zBq5hvaTldjG4CPb9wdxAme0SyedVKczJ9AtYbgPOzYKJvZZImsN7ecrxWZg5dR6ZLj/j4qpWsIA+vYwE+Tca9ounMIsrXMB4Stiib2SPQtZv+FVIpfEbzv8ncZoLBXc3YBqTG1HsskTTotZOYTG+oVUjLk6zhP8bg4RhMUNtfZdO7FdpBuXzhJ5Fh8IKlJG7wtD9ik8rWOJxy6iQ3NwzBpQ219mlyv+FLicYs2iJGSE0u2txzed++D61ZWCiHD/cZdQVCqkO2gJpdpNaObhnDfAPrT89RxdWFZ5hO3MseBSIlANppdZNIV/Rwe5eLTDvkfWKzFnH+QJ7m9QWV1KdwnuIwTNtZdJMoXBf74OhRnh2t+OTGL+AVUnIkyYY+QG7g9itHXyF3OIygG2s2kud679ZWKqSFa9n3IHD6MeLv1lZ0XyduRhiDRtrNnKoyiFVLcBm0ba5Yy3fQkDh4XsFE34isVpOzpa9nR8iCpS4HoxG2rJpnRhf3YboVa1PcRouh5LIJv/uQcPNd095ickTaiGBnWLKVWRc0OnYTSyex/n2FofEPnDG8y3PztHrzOLK1xo6RAml2k9owKajOC0Wr4D5x+3nA0UEhK2m198wuBHF3zlWWVKWLN1CHzLClUfuoYBcx4b1llpeBKmbayaR58njtE9onD66lUcsg0Spm2snsb+8HaJRn4dYcLbCuBuYwziB8/5U1C1DOOz2gZjSZtrLJk6vrLF3hwY4Io9xuT/ruUFRSBkNtUzTOWhjh26irLEPx4jPZL3Fo3QrReoGTTM21xYTT9oFdhTUIvjqTkfkvt0bzgVUjq/hOYY8j60IaO/0AzRBtqkTS6R5ellZd5uKdzzhb8BFlDdAcrwkE0rbXTOPB+7Y0FlZO96qFL4Ykg21StJs8qIW7h16H5hGiv8V2Cflau7QVDepTAHa6Lgt6feiEvJDM21StJsmOH/hynURrKxvUpQ8BH0JF7BiyG2qZpnL/7AOU66gt+reLEXY8pVOCQvSsBtqZTNM8bk9ohRcwD18o/WVkbvrceVKRb9I59IEKysjBeTMmmbA21xu/6iHadLRxuIzkLpi8wZYmmbbWi32RVAUjruxWlJ//iFxE38FI9hNKOoCdhwf5fDe4xZ81lgREhK2m1j78vW1CqkuMu/AjBNK210kzRUX/B+69cMMUG5bYrIeZxVSEZISmkzbXOi9yxwIfPgdsov7R71xuJ7rFcACjG/9PzApqFq7wEgzNJm2suWESPuwrQvejj7cbnQxMkxpm21lUYJL0fKmogPPqywn7e3FvB/FCNxPJ85iVUkCE9/tLKx31G4CgNtWTTPFhMvlu8G4/TrgaZttTChljfNJGgOT2X6EqpETy2tYd9cCBI4lIXJ1/3uVUllZEJz4baqGF64yxaZ+zPLYwde8Uqn1oKANtUrSaTOPHkhvuQP3bBlEJ/LFe4pqQOHUI8T8q7AXx3fLVBgSCVpMba55YxN3rv8U1Dv51bAPSOLlZWebkL8vSMGI21lJmmeVxPRwFlZF1CpqCN8uLwymaZyjbXHCRytogPN3o/n74CNykfT+qqRv5AQlHcRxYrC5KvGmbbUwmZY/29BvF6C1/93x4WVglXDLFpmbapmF89HKTogRwqqSlGbu+oiAkcWFbklC6Zhf+NtTLFpn8oWz+HsNRVSgIxZWON+yVyJlE5tq/+GWLTMutYX9ekTySEQPLVNQQ3OfycwJBM0zNtZcse7CvcKI0V/zh16Dr9OSA21MpmmcrHC+6pTAPHPwoit3LHHqs7jhFNRD6W8+EBGoSEoaZttTCZljfduH/fFisn+dRBGAZYtMzbVMwvul/T/crK1NQh8gN0SRRa9cOux6clC0/mDLFpmbarmF8/e6CopeOLCNW6S/IUUg3jJIYiAcDoMcGeRbOvuTPjXR/tyo79LK3kqqkbxkkMRAOB0GODPItnX3Jnxro/25Ud+llbyVVSN4ySGIgHA6DHBnkWzr7kz410f7cqO/Syt5KqpFVJwn6gBEvBM0zNtZcpGOEPiysW8vvRd2R0f7gtjhqUvXL+gWVwHm4XJDBiMpmmZtrLfPwd/IugP5+fKVSysH1EXreFAcEhelGmbbUmZY4Xdo1vQWVnK19P4RuEnbf0gQnR+lDCZlivNM22t1ESmopPIgfT0duOfQrsjgG4tPxli0zJmF5trdL1JDUIUT1ZXSqQDeR4B8mX3TrRro/2McGeUvLtwo6jIEKMkCUXWsLyZROd9P/rFYNtXPBli0z398iVUlVKAjFlY437JXImUTm2r/4ZYtMy61hf16RPJIU9nZ1MABAwAAAAAAAAAZpwgEwIAAABhp658BScAAAAAAADnUFBQXIDGXLhwtttNHDhw5OcpQRMETBEwRPduylKVB0HRdF0A",
        o = "data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28yYXZjMW1wNDEAAAAIZnJlZQAAAs1tZGF0AAACrgYF//+q3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE0OCByMjYwMSBhMGNkN2QzIC0gSC4yNjQvTVBFRy00IEFWQyBjb2RlYyAtIENvcHlsZWZ0IDIwMDMtMjAxNSAtIGh0dHA6Ly93d3cudmlkZW9sYW4ub3JnL3gyNjQuaHRtbCAtIG9wdGlvbnM6IGNhYmFjPTEgcmVmPTMgZGVibG9jaz0xOjA6MCBhbmFseXNlPTB4MzoweDExMyBtZT1oZXggc3VibWU9NyBwc3k9MSBwc3lfcmQ9MS4wMDowLjAwIG1peGVkX3JlZj0xIG1lX3JhbmdlPTE2IGNocm9tYV9tZT0xIHRyZWxsaXM9MSA4eDhkY3Q9MSBjcW09MCBkZWFkem9uZT0yMSwxMSBmYXN0X3Bza2lwPTEgY2hyb21hX3FwX29mZnNldD0tMiB0aHJlYWRzPTEgbG9va2FoZWFkX3RocmVhZHM9MSBzbGljZWRfdGhyZWFkcz0wIG5yPTAgZGVjaW1hdGU9MSBpbnRlcmxhY2VkPTAgYmx1cmF5X2NvbXBhdD0wIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PTI1MCBrZXlpbnRfbWluPTEwIHNjZW5lY3V0PTQwIGludHJhX3JlZnJlc2g9MCByY19sb29rYWhlYWQ9NDAgcmM9Y3JmIG1idHJlZT0xIGNyZj0yMy4wIHFjb21wPTAuNjAgcXBtaW49MCBxcG1heD02OSBxcHN0ZXA9NCBpcF9yYXRpbz0xLjQwIGFxPTE6MS4wMACAAAAAD2WIhAA3//728P4FNjuZQQAAAu5tb292AAAAbG12aGQAAAAAAAAAAAAAAAAAAAPoAAAAZAABAAABAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAACGHRyYWsAAABcdGtoZAAAAAMAAAAAAAAAAAAAAAEAAAAAAAAAZAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAEAAAAAAAgAAAAIAAAAAACRlZHRzAAAAHGVsc3QAAAAAAAAAAQAAAGQAAAAAAAEAAAAAAZBtZGlhAAAAIG1kaGQAAAAAAAAAAAAAAAAAACgAAAAEAFXEAAAAAAAtaGRscgAAAAAAAAAAdmlkZQAAAAAAAAAAAAAAAFZpZGVvSGFuZGxlcgAAAAE7bWluZgAAABR2bWhkAAAAAQAAAAAAAAAAAAAAJGRpbmYAAAAcZHJlZgAAAAAAAAABAAAADHVybCAAAAABAAAA+3N0YmwAAACXc3RzZAAAAAAAAAABAAAAh2F2YzEAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAgACAEgAAABIAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY//8AAAAxYXZjQwFkAAr/4QAYZ2QACqzZX4iIhAAAAwAEAAADAFA8SJZYAQAGaOvjyyLAAAAAGHN0dHMAAAAAAAAAAQAAAAEAAAQAAAAAHHN0c2MAAAAAAAAAAQAAAAEAAAABAAAAAQAAABRzdHN6AAAAAAAAAsUAAAABAAAAFHN0Y28AAAAAAAAAAQAAADAAAABidWR0YQAAAFptZXRhAAAAAAAAACFoZGxyAAAAAAAAAABtZGlyYXBwbAAAAAAAAAAAAAAAAC1pbHN0AAAAJal0b28AAAAdZGF0YQAAAAEAAAAATGF2ZjU2LjQwLjEwMQ==";
    t.OggVideo = n, t.Mp4Video = o
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.initializeVimeoPlayer = t.initializeVimeoAPI = void 0;
    var o = n(15),
        i = n(16),
        r = void 0,
        a = "*",
        s = null,
        l = function() {
            return new Promise(function(e, t) {
                e("no api needed")
            })
        },
        c = function(e, t) {
            var n = {
                method: e
            };
            t && (n.value = t);
            var o = JSON.stringify(n);
            r.ownerDocument.defaultView.eval("(function(playerIframe){ playerIframe.contentWindow.postMessage(" + o + ", " + JSON.stringify(a) + ") })")(r)
        },
        u = function(e) {
            var t = e.win,
                n = e.instance,
                l = e.container,
                u = e.videoId,
                d = e.startTime,
                A = e.readyCallback,
                f = e.stateChangeCallback;
            return new Promise(function(e, h) {
                var p = n.logger || function() {};
                r = t.document.createElement("iframe"), r.id = "vimeoplayer";
                var g = "&background=1";
                r.src = "//player.vimeo.com/video/" + u + "?api=1" + g;
                var y = (0, o.getPlayerElement)(l);
                y.appendChild(r);
                var v = {
                    iframe: r,
                    setPlaybackRate: function() {}
                };
                e(v);
                var m = function() {
                        c("getDuration"), c("getVideoHeight"), c("getVideoWidth")
                    },
                    b = null,
                    w = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        (e || v.dimensions.width && v.dimensions.height && v.duration) && (e && m(), v.dimensions.width = v.dimensions.width || v.iframe.parentNode.offsetWidth, v.dimensions.height = v.dimensions.height || v.iframe.parentNode.offsetHeight, v.duration = v.duration || 10, c("setVolume", "0"), c("setLoop", "true"), c("seekTo", d), c("addEventListener", "playProgress"), A(v))
                    },
                    E = function() {
                        s && (clearTimeout(s), s = null), v.dimensions || (v.dimensions = {}, m(), f("buffering"), b = setTimeout(function() {
                            p.call(n, "retrying"), w(!0)
                        }, .75 * i.TIMEOUT))
                    },
                    _ = function(e) {
                        if (!/^https?:\/\/player.vimeo.com/.test(e.origin)) return !1;
                        a = e.origin;
                        var t = e.data;
                        switch ("string" == typeof t && (t = JSON.parse(t)), t.event) {
                            case "ready":
                                E(a);
                                break;
                            case "playProgress":
                            case "timeupdate":
                                b && (clearTimeout(b), b = null), f("playing", t), c("setVolume", "0"), t.data.percent >= .98 && d > 0 && c("seekTo", d)
                        }
                        switch (t.method) {
                            case "getVideoHeight":
                                p.call(n, t.method), v.dimensions.height = t.value, w();
                                break;
                            case "getVideoWidth":
                                p.call(n, t.method), v.dimensions.width = t.value, w();
                                break;
                            case "getDuration":
                                p.call(n, t.method), v.duration = t.value, d >= v.duration && (d = 0), w()
                        }
                    },
                    k = function(e) {
                        _(e)
                    };
                t.addEventListener("message", k, !1), v.destroy = function() {
                    t.removeEventListener("message", k), v.iframe.parentElement && v.iframe.parentElement.removeChild(v.iframe)
                }, s = setTimeout(function() {
                    h("Ran out of time")
                }, i.TIMEOUT)
            })
        };
    t.initializeVimeoAPI = l, t.initializeVimeoPlayer = u
}, function(e, t, n) {
    "use strict";

    function o(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.validatedImage = t.getVideoSource = t.getVideoID = t.getStartTime = t.getPlayerElement = t.findPlayerAspectRatio = void 0;
    var i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        },
        r = n(16),
        a = n(17),
        s = o(a),
        l = n(21),
        c = o(l),
        u = function(e) {
            var t = void 0,
                n = void 0;
            for (var o in e) {
                var r = e[o];
                if ("object" === ("undefined" == typeof r ? "undefined" : i(r)) && r.width && r.height) {
                    t = r.width, n = r.height;
                    break
                }
            }
            return {
                w: t,
                h: n
            }
        },
        d = function(e) {
            var t = void 0,
                n = void 0;
            return e.dimensions ? (t = e.dimensions.width, n = e.dimensions.height) : e.iframe && (t = e.iframe.clientWidth, n = e.iframe.clientHeight), {
                w: t,
                h: n
            }
        },
        A = {
            youtube: {
                parsePath: "query.t",
                timeRegex: /[hms]/,
                idRegex: r.YOUTUBE_REGEX,
                getDimensions: u
            },
            vimeo: {
                parsePath: null,
                timeRegex: /[#t=s]/,
                idRegex: r.VIMEO_REGEX,
                getDimensions: d
            }
        },
        f = function(e, t) {
            return A[t].parsePath ? (0, c.default)(e, A[t].parsePath) : null
        },
        h = function(e, t) {
            var n = new s.default(e, !0),
                o = f(n, t);
            if (o) {
                var i = o.split(A[t].timeRegex).filter(Boolean),
                    r = parseInt(i.pop(), 10) || 0,
                    a = 60 * parseInt(i.pop(), 10) || 0,
                    l = 3600 * parseInt(i.pop(), 10) || 0;
                return l + a + r
            }
        },
        p = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r.DEFAULT_PROPERTY_VALUES.url,
                t = e.match(r.YOUTUBE_REGEX);
            return t && t[2].length ? "youtube" : (t = e.match(r.VIMEO_REGEX), t && t[3].length ? "vimeo" : void console.error("Video source " + e + " does not match supported types"))
        },
        g = function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r.DEFAULT_PROPERTY_VALUES.url,
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
                n = A[t],
                o = n && e.match(n.idRegex),
                i = "vimeo" === t ? o[3] : o[2];
            return o && i.length ? i : void console.error("Video id at " + e + " is not valid")
        },
        y = function(e) {
            if (!e) return !1;
            var t = "IMG" === e.nodeName && e;
            return t || console.warn("Element is not a valid image element."), t
        },
        v = function(e, t, n) {
            var o = void 0,
                i = void 0;
            if (t) {
                var r = A[n].getDimensions(t);
                o = r.w, i = r.h
            }
            return o && i || (o = e.clientWidth, i = e.clientHeight, console.warn("No width and height found in " + n + " player " + t + ". Using container dimensions.")), parseInt(o, 10) / parseInt(i, 10)
        },
        m = function(e) {
            var t = e.querySelector("#player");
            return t || (t = e.ownerDocument.createElement("div"), t.id = "player", e.appendChild(t)), t.setAttribute("style", "position: absolute; top: 0; bottom: 0; left: 0; right: 0;"), t
        };
    t.findPlayerAspectRatio = v, t.getPlayerElement = m, t.getStartTime = h, t.getVideoID = g, t.getVideoSource = p, t.validatedImage = y
}, function(e, t) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = {
            enabled: !0,
            verbose: !1
        },
        o = {
            container: "body",
            url: "https://youtu.be/xkEmYQvJ_68",
            source: "youtube",
            fitMode: "fill",
            scaleFactor: 1,
            playbackSpeed: 1,
            filter: 1,
            filterStrength: 50,
            timeCode: {
                start: 0,
                end: null
            },
            DEBUG: n
        },
        i = 2500,
        r = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]{11}).*/,
        a = /^.*(vimeo\.com\/)(channels\/[a-zA-Z0-9]*\/)?([0-9]{7,}(#t\=.*s)?)/;
    t.DEBUG = n, t.DEFAULT_PROPERTY_VALUES = o, t.TIMEOUT = i, t.YOUTUBE_REGEX = r, t.VIMEO_REGEX = a
}, function(e, t, n) {
    "use strict";

    function o(e) {
        var t = c.exec(e);
        return {
            protocol: t[1] ? t[1].toLowerCase() : "",
            slashes: !!t[2],
            rest: t[3] ? t[3] : ""
        }
    }

    function i(e, t, n) {
        if (!(this instanceof i)) return new i(e, t, n);
        var c, d, A, f, h = l.test(e),
            p = typeof t,
            g = this,
            y = 0;
        "object" !== p && "string" !== p && (n = t, t = null), n && "function" != typeof n && (n = s.parse), t = a(t);
        var v = o(e);
        for (g.protocol = v.protocol || t.protocol || "", g.slashes = v.slashes || t.slashes, e = v.rest; y < u.length; y++) d = u[y],
            c = d[0], f = d[1], c !== c ? g[f] = e : "string" == typeof c ? ~(A = e.indexOf(c)) && ("number" == typeof d[2] ? (g[f] = e.slice(0, A), e = e.slice(A + d[2])) : (g[f] = e.slice(A), e = e.slice(0, A))) : (A = c.exec(e)) && (g[f] = A[1], e = e.slice(0, e.length - A[0].length)), g[f] = g[f] || (d[3] || "port" === f && h ? t[f] || "" : ""), d[4] && (g[f] = g[f].toLowerCase());
        n && (g.query = n(g.query)), r(g.port, g.protocol) || (g.host = g.hostname, g.port = ""), g.username = g.password = "", g.auth && (d = g.auth.split(":"), g.username = d[0] || "", g.password = d[1] || ""), g.href = g.toString()
    }
    var r = n(18),
        a = n(19),
        s = n(20),
        l = /^\/(?!\/)/,
        c = /^([a-z0-9.+-]+:)?(\/\/)?(.*)$/i,
        u = [
            ["#", "hash"],
            ["?", "query"],
            ["/", "pathname"],
            ["@", "auth", 1],
            [NaN, "host", void 0, 1, 1],
            [/\:(\d+)$/, "port"],
            [NaN, "hostname", void 0, 1, 1]
        ];
    i.prototype.set = function(e, t, n) {
        var o = this;
        return "query" === e ? ("string" == typeof t && t.length && (t = (n || s.parse)(t)), o[e] = t) : "port" === e ? (o[e] = t, r(t, o.protocol) ? t && (o.host = o.hostname + ":" + t) : (o.host = o.hostname, o[e] = "")) : "hostname" === e ? (o[e] = t, o.port && (t += ":" + o.port), o.host = t) : "host" === e ? (o[e] = t, /\:\d+/.test(t) && (t = t.split(":"), o.hostname = t[0], o.port = t[1])) : "protocol" === e ? (o.protocol = t, o.slashes = !n) : o[e] = t, o.href = o.toString(), o
    }, i.prototype.toString = function(e) {
        e && "function" == typeof e || (e = s.stringify);
        var t, n = this,
            o = n.protocol;
        o && ":" !== o.charAt(o.length - 1) && (o += ":");
        var i = o + (n.slashes ? "//" : "");
        return n.username && (i += n.username, n.password && (i += ":" + n.password), i += "@"), i += n.hostname, n.port && (i += ":" + n.port), i += n.pathname, t = "object" == typeof n.query ? e(n.query) : n.query, t && (i += "?" !== t.charAt(0) ? "?" + t : t), n.hash && (i += n.hash), i
    }, i.qs = s, i.location = a, e.exports = i
}, function(e, t) {
    "use strict";
    e.exports = function(e, t) {
        if (t = t.split(":")[0], e = +e, !e) return !1;
        switch (t) {
            case "http":
            case "ws":
                return 80 !== e;
            case "https":
            case "wss":
                return 443 !== e;
            case "ftp":
                return 21 !== e;
            case "gopher":
                return 70 !== e;
            case "file":
                return !1
        }
        return 0 !== e
    }
}, function(e, t, n) {
    (function(t) {
        "use strict";
        var o, i = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
            r = {
                hash: 1,
                query: 1
            };
        e.exports = function(e) {
            e = e || t.location || {}, o = o || n(17);
            var a, s = {},
                l = typeof e;
            if ("blob:" === e.protocol) s = new o(unescape(e.pathname), {});
            else if ("string" === l) {
                s = new o(e, {});
                for (a in r) delete s[a]
            } else if ("object" === l) {
                for (a in e) a in r || (s[a] = e[a]);
                void 0 === s.slashes && (s.slashes = i.test(e.href))
            }
            return s
        }
    }).call(t, function() {
        return this
    }())
}, function(e, t) {
    "use strict";

    function n(e) {
        for (var t, n = /([^=?&]+)=?([^&]*)/g, o = {}; t = n.exec(e); o[decodeURIComponent(t[1])] = decodeURIComponent(t[2]));
        return o
    }

    function o(e, t) {
        t = t || "";
        var n = [];
        "string" != typeof t && (t = "?");
        for (var o in e) i.call(e, o) && n.push(encodeURIComponent(o) + "=" + encodeURIComponent(e[o]));
        return n.length ? t + n.join("&") : ""
    }
    var i = Object.prototype.hasOwnProperty;
    t.stringify = o, t.parse = n
}, function(e, t) {
    (function(t) {
        function n(e, t) {
            return null == e ? void 0 : e[t]
        }

        function o(e) {
            var t = !1;
            if (null != e && "function" != typeof e.toString) try {
                t = !!(e + "")
            } catch (e) {}
            return t
        }

        function i(e) {
            var t = -1,
                n = e ? e.length : 0;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }

        function r() {
            this.__data__ = ge ? ge(null) : {}
        }

        function a(e) {
            return this.has(e) && delete this.__data__[e]
        }

        function s(e) {
            var t = this.__data__;
            if (ge) {
                var n = t[e];
                return n === L ? void 0 : n
            }
            return ue.call(t, e) ? t[e] : void 0
        }

        function l(e) {
            var t = this.__data__;
            return ge ? void 0 !== t[e] : ue.call(t, e)
        }

        function c(e, t) {
            var n = this.__data__;
            return n[e] = ge && void 0 === t ? L : t, this
        }

        function u(e) {
            var t = -1,
                n = e ? e.length : 0;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }

        function d() {
            this.__data__ = []
        }

        function A(e) {
            var t = this.__data__,
                n = E(t, e);
            if (n < 0) return !1;
            var o = t.length - 1;
            return n == o ? t.pop() : he.call(t, n, 1), !0
        }

        function f(e) {
            var t = this.__data__,
                n = E(t, e);
            return n < 0 ? void 0 : t[n][1]
        }

        function h(e) {
            return E(this.__data__, e) > -1
        }

        function p(e, t) {
            var n = this.__data__,
                o = E(n, e);
            return o < 0 ? n.push([e, t]) : n[o][1] = t, this
        }

        function g(e) {
            var t = -1,
                n = e ? e.length : 0;
            for (this.clear(); ++t < n;) {
                var o = e[t];
                this.set(o[0], o[1])
            }
        }

        function y() {
            this.__data__ = {
                hash: new i,
                map: new(pe || u),
                string: new i
            }
        }

        function v(e) {
            return x(this, e).delete(e)
        }

        function m(e) {
            return x(this, e).get(e)
        }

        function b(e) {
            return x(this, e).has(e)
        }

        function w(e, t) {
            return x(this, e).set(e, t), this
        }

        function E(e, t) {
            for (var n = e.length; n--;)
                if (Y(e[n][0], t)) return n;
            return -1
        }

        function _(e, t) {
            t = R(t, e) ? [t] : T(t);
            for (var n = 0, o = t.length; null != e && n < o;) e = e[C(t[n++])];
            return n && n == o ? e : void 0
        }

        function k(e) {
            if (!U(e) || F(e)) return !1;
            var t = j(e) || o(e) ? Ae : ee;
            return t.test(V(e))
        }

        function S(e) {
            if ("string" == typeof e) return e;
            if (O(e)) return ve ? ve.call(e) : "";
            var t = e + "";
            return "0" == t && 1 / e == -Q ? "-0" : t
        }

        function T(e) {
            return be(e) ? e : me(e)
        }

        function x(e, t) {
            var n = e.__data__;
            return I(t) ? n["string" == typeof t ? "string" : "hash"] : n.map
        }

        function P(e, t) {
            var o = n(e, t);
            return k(o) ? o : void 0
        }

        function R(e, t) {
            if (be(e)) return !1;
            var n = typeof e;
            return !("number" != n && "symbol" != n && "boolean" != n && null != e && !O(e)) || (q.test(e) || !W.test(e) || null != t && e in Object(t))
        }

        function I(e) {
            var t = typeof e;
            return "string" == t || "number" == t || "symbol" == t || "boolean" == t ? "__proto__" !== e : null === e
        }

        function F(e) {
            return !!le && le in e
        }

        function C(e) {
            if ("string" == typeof e || O(e)) return e;
            var t = e + "";
            return "0" == t && 1 / e == -Q ? "-0" : t
        }

        function V(e) {
            if (null != e) {
                try {
                    return ce.call(e)
                } catch (e) {}
                try {
                    return e + ""
                } catch (e) {}
            }
            return ""
        }

        function B(e, t) {
            if ("function" != typeof e || t && "function" != typeof t) throw new TypeError(D);
            var n = function() {
                var o = arguments,
                    i = t ? t.apply(this, o) : o[0],
                    r = n.cache;
                if (r.has(i)) return r.get(i);
                var a = e.apply(this, o);
                return n.cache = r.set(i, a), a
            };
            return n.cache = new(B.Cache || g), n
        }

        function Y(e, t) {
            return e === t || e !== e && t !== t
        }

        function j(e) {
            var t = U(e) ? de.call(e) : "";
            return t == Z || t == z
        }

        function U(e) {
            var t = typeof e;
            return !!e && ("object" == t || "function" == t)
        }

        function G(e) {
            return !!e && "object" == typeof e
        }

        function O(e) {
            return "symbol" == typeof e || G(e) && de.call(e) == H
        }

        function M(e) {
            return null == e ? "" : S(e)
        }

        function N(e, t, n) {
            var o = null == e ? void 0 : _(e, t);
            return void 0 === o ? n : o
        }
        var D = "Expected a function",
            L = "__lodash_hash_undefined__",
            Q = 1 / 0,
            Z = "[object Function]",
            z = "[object GeneratorFunction]",
            H = "[object Symbol]",
            W = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
            q = /^\w*$/,
            J = /^\./,
            X = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            K = /[\\^$.*+?()[\]{}|]/g,
            $ = /\\(\\)?/g,
            ee = /^\[object .+?Constructor\]$/,
            te = "object" == typeof t && t && t.Object === Object && t,
            ne = "object" == typeof self && self && self.Object === Object && self,
            oe = te || ne || Function("return this")(),
            ie = Array.prototype,
            re = Function.prototype,
            ae = Object.prototype,
            se = oe["__core-js_shared__"],
            le = function() {
                var e = /[^.]+$/.exec(se && se.keys && se.keys.IE_PROTO || "");
                return e ? "Symbol(src)_1." + e : ""
            }(),
            ce = re.toString,
            ue = ae.hasOwnProperty,
            de = ae.toString,
            Ae = RegExp("^" + ce.call(ue).replace(K, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
            fe = oe.Symbol,
            he = ie.splice,
            pe = P(oe, "Map"),
            ge = P(Object, "create"),
            ye = fe ? fe.prototype : void 0,
            ve = ye ? ye.toString : void 0;
        i.prototype.clear = r, i.prototype.delete = a, i.prototype.get = s, i.prototype.has = l, i.prototype.set = c, u.prototype.clear = d, u.prototype.delete = A, u.prototype.get = f, u.prototype.has = h, u.prototype.set = p, g.prototype.clear = y, g.prototype.delete = v, g.prototype.get = m, g.prototype.has = b, g.prototype.set = w;
        var me = B(function(e) {
            e = M(e);
            var t = [];
            return J.test(e) && t.push(""), e.replace(X, function(e, n, o, i) {
                t.push(o ? i.replace($, "$1") : n || e)
            }), t
        });
        B.Cache = g;
        var be = Array.isArray;
        e.exports = N
    }).call(t, function() {
        return this
    }())
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.initializeYouTubePlayer = t.initializeYouTubeAPI = void 0;
    var o = n(15),
        i = function(e) {
            return new Promise(function(t, n) {
                if (e.document.documentElement.querySelector('script[src*="www.youtube.com/iframe_api"].loaded')) return void t("already loaded");
                var o = e.document.createElement("script");
                o.src = "https://www.youtube.com/iframe_api";
                var i = e.document.getElementsByTagName("script")[0];
                i.parentNode.insertBefore(o, i), o.addEventListener("load", function(e) {
                    e.currentTarget.classList.add("loaded"), t("api script tag created and loaded")
                }, !0), o.addEventListener("error", function(e) {
                    n("Failed to load YouTube script: ", e)
                })
            })
        },
        r = function(e, t) {
            var n = e.target;
            n.iframe = n.getIframe(), n.mute(), n.ready = !0, n.seekTo(t < n.getDuration() ? t : 0), n.playVideo()
        },
        a = function(e, t, n) {
            var o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 1,
                i = e.target,
                r = (i.getDuration() - t) / o,
                a = function e() {
                    i.getCurrentTime() + .1 >= i.getDuration() && (i.pauseVideo(), i.seekTo(t), i.playVideo()), requestAnimationFrame(e)
                };
            return e.data === n.YT.PlayerState.BUFFERING && 1 !== i.getVideoLoadedFraction() && (0 === i.getCurrentTime() || i.getCurrentTime() > r - -.1) ? "buffering" : e.data === n.YT.PlayerState.PLAYING ? (requestAnimationFrame(a), "playing") : void(e.data === n.YT.PlayerState.ENDED && i.playVideo())
        },
        s = function(e) {
            var t = e.container,
                n = e.win,
                i = e.videoId,
                s = e.startTime,
                l = e.speed,
                c = e.readyCallback,
                u = e.stateChangeCallback,
                d = (0, o.getPlayerElement)(t),
                A = function() {
                    return new n.YT.Player(d, {
                        videoId: i,
                        playerVars: {
                            autohide: 1,
                            autoplay: 0,
                            controls: 0,
                            enablejsapi: 1,
                            iv_load_policy: 3,
                            loop: 0,
                            modestbranding: 1,
                            playsinline: 1,
                            rel: 0,
                            showinfo: 0,
                            wmode: "opaque"
                        },
                        events: {
                            onReady: function(e) {
                                r(e, s), c(e.target)
                            },
                            onStateChange: function(e) {
                                var t = a(e, s, n, l);
                                u(t, t)
                            }
                        }
                    })
                };
            return new Promise(function(e, t) {
                var o = function t() {
                    1 === n.YT.loaded ? e(A()) : setTimeout(t, 100)
                };
                o()
            })
        };
    t.initializeYouTubeAPI = i, t.initializeYouTubePlayer = s
}, function(e, t) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = ["none", "blur", "brightness", "contrast", "invert", "opacity", "saturate", "sepia", "drop-shadow", "grayscale", "hue-rotate"],
        o = {
            blur: {
                modifier: function(e) {
                    return .3 * e
                },
                unit: "px"
            },
            brightness: {
                modifier: function(e) {
                    return .009 * e + .1
                },
                unit: ""
            },
            contrast: {
                modifier: function(e) {
                    return .4 * e + 80
                },
                unit: "%"
            },
            grayscale: {
                modifier: function(e) {
                    return e
                },
                unit: "%"
            },
            "hue-rotate": {
                modifier: function(e) {
                    return 3.6 * e
                },
                unit: "deg"
            },
            invert: {
                modifier: function(e) {
                    return 1
                },
                unit: ""
            },
            opacity: {
                modifier: function(e) {
                    return e
                },
                unit: "%"
            },
            saturate: {
                modifier: function(e) {
                    return 2 * e
                },
                unit: "%"
            },
            sepia: {
                modifier: function(e) {
                    return e
                },
                unit: "%"
            }
        };
    t.filterOptions = n, t.filterProperties = o
}, function(e, t) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var n = function(e) {
        var t = {
            container: e
        };
        return e.getAttribute("data-config-url") && (t.url = e.getAttribute("data-config-url")), e.getAttribute("data-config-playback-speed") && (t.playbackSpeed = e.getAttribute("data-config-playback-speed")), e.getAttribute("data-config-filter") && (t.filter = e.getAttribute("data-config-filter")), e.getAttribute("data-config-filter-strength") && (t.filterStrength = e.getAttribute("data-config-filter-strength")), t
    };
    t.default = n, e.exports = t.default
}, function(e, t, n) {
    var o = n(2),
        i = n(26),
        r = n(17);
    Y.use("node", function() {
        window.Singleton.create({
            ready: function() {
                this._touch = Y.one(".touch-styles"), this.bindUI(), this._touch || (this.folderRedirect(".folder-toggle", "#headerNav"), this.folderRedirect(".folder-toggle", "#footer")), this.folderActive(".folder-toggle", "#mobileNavigation"), this.folderActive(".folder-toggle", "#headerNav"), this.folderActive(".folder-toggle", "#footer"), this.folderNavExpand(".folder-nav-toggle", "#folderNav"), this.folderNavExpand(".category-nav-toggle", "#categoryNav")
            },
            bindUI: function() {
                this.dataToggleBody(), this.dataToggleEl(), this.dataLightbox(), this.scrollAnchors(), Y.one(window).on("resize", this.syncUI, this)
            },
            syncUI: function() {
                o(function() {
                    i()
                }, 100, this)
            },
            folderNavExpand: function(e, t) {
                var n = Y.one(t);
                n && n.one(e).on("click", function() {
                    n.toggleClass("expanded")
                })
            },
            folderActive: function(e, t) {
                e = e || ".folder-toggle", t = t || "body";
                var n = Y.all(t);
                n.size() > 0 && n.each(function(t) {
                    t.delegate("click", function(e) {
                        e.preventDefault(), e.currentTarget.toggleClass("active"), e.currentTarget.ancestor(".folder").siblings(".folder").each(function(e) {
                            e.one(".folder-toggle").removeClass("active")
                        })
                    }, e)
                })
            },
            folderRedirect: function(e, t) {
                e = e || ".folder-toggle", t = t || "body";
                var n = Y.all(t);
                n.size() > 0 && n.each(function(t) {
                    t.delegate("click", function(e) {
                        e.preventDefault();
                        var t = e.currentTarget.getData("href");
                        t ? window.location = t : console.warn("folderRedirect: You must add a data-href attribute to the label.")
                    }, e)
                })
            },
            dataLightbox: function() {
                var e = {};
                Y.all("[data-lightbox]").each(function(t) {
                    var n = t.getAttribute("data-lightbox");
                    e[n] = e[n] || [], e[n].push({
                        content: t,
                        meta: t.getAttribute("alt")
                    }), t.on("click", function(o) {
                        o.halt(), new Y.Squarespace.Lightbox2({
                            set: e[n],
                            currentSetIndex: Y.all("[data-lightbox]").indexOf(t),
                            controls: {
                                previous: !0,
                                next: !0
                            }
                        }).render()
                    })
                })
            },
            dataToggleBody: function() {
                Y.one("body").delegate("click", function(e) {
                    Y.one("body").toggleClass(e.currentTarget.getData("toggle-body"))
                }, "[data-toggle-body]")
            },
            dataToggleEl: function() {
                Y.one("body").delegate("click", function(e) {
                    var t = e.currentTarget;
                    t.toggleClass(t.getData("toggle"))
                }, "[data-toggle]")
            },
            scrollAnchors: function() {
                if (!history.pushState) return !1;
                var e = 'a[href*="#"]';
                Y.one("body").delegate("click", function(e) {
                    var t = e.currentTarget.get("href"),
                        n = this._getSamePageHash(t);
                    n && Y.one(n) && (e.halt(), Y.one("#mobileNavToggle") && Y.one("#mobileNavToggle").set("checked", !1).simulate("change"), this.smoothScrollTo(Y.one(n).getY()), history.pushState({}, n, n))
                }, e, this)
            },
            _getSamePageHash: function(e) {
                var e = new r(e),
                    t = new r(window.location.href);
                return e.host !== t.host || e.pathname !== t.pathname || "" === e.hash ? null : e.hash
            },
            smoothScrollTo: function(e) {
                if (!Y.Lang.isNumber(e)) try {
                    e = parseInt(e)
                } catch (e) {
                    return console.warn("helpers.js: scrollTo was passed an invalid argument."), !1
                }
                var t = Y.UA.gecko || Y.UA.ie || navigator.userAgent.match(/Trident.*rv.11\./) ? "html" : "body",
                    n = new Y.Anim({
                        node: Y.one(document.scrollingElement || t),
                        to: {
                            scrollTop: e
                        },
                        duration: .4,
                        easing: "easeOut"
                    });
                n.run(), n.on("end", function() {
                    n.destroy()
                })
            }
        })
    })
}, function(e, t) {
    function n(e) {
        e = e || "img[data-src]", Y.one(e) && Y.all(e).each(function(e) {
            ImageLoader.load(e)
        })
    }
    e.exports = n
}, function(e, t, n) {
    var o = n(2),
        i = n(26),
        r = null !== document.documentElement.getAttribute("data-authenticated-account");
    r && Y.use("node", function(e) {
        window.Singleton.create({
            ready: function() {
                this.bindUI()
            },
            bindUI: function() {
                e.Global.on("tweak:change", function(t) {
                    var n = e.one("#mobileNavToggle");
                    if (n) {
                        var r = t.config && "Site Navigation" === t.config.category;
                        n.set("checked", r)
                    }
                    "transparent-header" === t.getName() && o(function() {
                        i()
                    }, 100, this)
                });
                var t = e.one("body.transparent-header");
                t && (t = t.getDOMNode(), ["sqs-stacked-items-dom-deleted", "sqs-stacked-items-dom-reorder"].forEach(function(n) {
                    e.config.win.addEventListener(n, function(e) {
                        var n = t.querySelector("#content > div");
                        n.querySelector(".banner-thumbnail-wrapper") || n.querySelector(".promoted-gallery-wrapper").children.length ? t.classList.add("has-banner-image") : t.classList.remove("has-banner-image")
                    }.bind(this))
                }.bind(this)))
            }
        })
    })
}]);