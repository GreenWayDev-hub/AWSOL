(function(n) {
    var r = {};

    function o(e) {
        if (r[e]) return r[e].exports;
        var t = r[e] = {
            i: e,
            l: false,
            exports: {}
        };
        n[e].call(t.exports, t, t.exports, o);
        t.l = true;
        return t.exports
    }
    o.m = n;
    o.c = r;
    o.d = function(e, t, n) {
        o.o(e, t) || Object.defineProperty(e, t, {
            enumerable: true,
            get: n
        })
    };
    o.r = function(e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        });
        Object.defineProperty(e, "__esModule", {
            value: true
        })
    };
    o.t = function(t, e) {
        1 & e && (t = o(t));
        if (8 & e) return t;
        if (4 & e && "object" === typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        o.r(n);
        Object.defineProperty(n, "default", {
            enumerable: true,
            value: t
        });
        if (2 & e && "string" != typeof t)
            for (var r in t) o.d(n, r, function(e) {
                return t[e]
            }.bind(null, r));
        return n
    };
    o.n = function(t) {
        var e = t && t.__esModule ? function e() {
            return t["default"]
        } : function e() {
            return t
        };
        o.d(e, "a", e);
        return e
    };
    o.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    };
    o.p = "https://assets.squarespace.com/universal/scripts-compressed/";
    return o(o.s = "./src/main/webapp/universal/src/apps/Performance/bootstrap.js")
})({
    "./common/temp/node_modules/@babel/runtime/helpers/defineProperty.js": function(e, t) {
        function n(e, t, n) {
            t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: true,
                configurable: true,
                writable: true
            }) : e[t] = n;
            return e
        }
        e.exports = n
    },
    "./common/temp/node_modules/@babel/runtime/helpers/interopRequireDefault.js": function(e, t) {
        function n(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        e.exports = n
    },
    "./common/temp/node_modules/@sqs/praetor/build/module/index.js": function(e, t, n) {
        "use strict";
        n.r(t);
        n.d(t, "StaticPraetorClient", function() {
            return c
        });
        n.d(t, "Configuration", function() {
            return o
        });
        n.d(t, "ExperimentType", function() {
            return a
        });
        var r = "true";
        var i = "default";
        var a;
        (function(e) {
            e["FEATURE_TOGGLE"] = "FEATURE_TOGGLE";
            e["AB_TEST"] = "AB_TEST"
        })(a = a || {});
        var o = function() {
            function e(e) {
                var t = this;
                this.experiments = {};
                this.isConfigurationLoaded = Boolean(e.isConfigurationLoaded);
                Array.isArray(e.experimentContextList) && e.experimentContextList.forEach(function(e) {
                    null !== e && "object" === typeof e && e.hasOwnProperty("name") && (t.experiments[e.name] = e)
                })
            }
            e.prototype.isValid = function() {
                return this.isConfigurationLoaded
            };
            e.prototype.getContext = function(e) {
                return this.experiments[e]
            };
            return e
        }();
        var u = function() {
            function e(e) {
                this.configuration = new o(e)
            }
            e.prototype.getFeatureToggle = function(e, t) {
                var n = this.getContextValidity(e, a.FEATURE_TOGGLE),
                    r = n.context,
                    o = n.error;
                if (o || null === r) return {
                    enabled: t,
                    error: o
                };
                if (r.containsError) return {
                    enabled: this.isFeatureToggleEnabled(r),
                    error: "The specified feature has an invalid server-side definition"
                };
                return {
                    enabled: this.isFeatureToggleEnabled(r)
                }
            };
            e.prototype.getABTestVariant = function(e, t) {
                var n = this.getContextValidity(e, a.AB_TEST),
                    r = n.context,
                    o = n.error;
                if (o || null === r) return {
                    error: o,
                    segment: i,
                    variant: t
                };
                if (r.containsError) return {
                    error: "The specified feature has an invalid server-side definition",
                    segment: r.segmentName,
                    variant: r.variant
                };
                return {
                    segment: r.segmentName,
                    variant: r.variant
                }
            };
            e.prototype.getAllExperiments = function() {
                return this.configuration
            };
            e.prototype.getContextValidity = function(e, t) {
                if (!this.configuration.isValid()) return {
                    context: null,
                    error: "The underlying Praetor configuration is not loaded"
                };
                var n = this.configuration.getContext(e);
                if (void 0 === n) return {
                    context: null,
                    error: "The specified feature does not exist"
                };
                if (n.experimentType !== t) return {
                    context: null,
                    error: "The specified feature is not a " + t
                };
                return {
                    context: n
                }
            };
            e.prototype.isFeatureToggleEnabled = function(e) {
                return e.variant === r
            };
            return e
        }();
        var c = u
    },
    "./common/temp/node_modules/@sqs/rum-collector/lib/constants.js": function(e, t, n) {
        "use strict";
        n.d(t, "n", function() {
            return o
        });
        n.d(t, "o", function() {
            return i
        });
        n.d(t, "p", function() {
            return a
        });
        n.d(t, "q", function() {
            return u
        });
        n.d(t, "s", function() {
            return c
        });
        n.d(t, "k", function() {
            return m
        });
        n.d(t, "t", function() {
            return w
        });
        n.d(t, "l", function() {
            return b
        });
        n.d(t, "g", function() {
            return y
        });
        n.d(t, "i", function() {
            return g
        });
        n.d(t, "d", function() {
            return E
        });
        n.d(t, "f", function() {
            return _
        });
        n.d(t, "c", function() {
            return S
        });
        n.d(t, "j", function() {
            return O
        });
        n.d(t, "r", function() {
            return T
        });
        n.d(t, "h", function() {
            return j
        });
        n.d(t, "a", function() {
            return P
        });
        n.d(t, "m", function() {
            return C
        });
        n.d(t, "b", function() {
            return L
        });
        n.d(t, "e", function() {
            return x
        });
        var r = n("./common/temp/node_modules/@sqs/rum-collector/node_modules/tslib/tslib.es6.js");
        var o = "/api/1/performance";
        var i = "/records";
        var a = "/settings";
        var u = "4.0.7";
        var c = function(e) {
            return {
                app: "a",
                data: {
                    __encoding_config__: e,
                    __encoding_key__: "d"
                },
                event: "e",
                pageLoadId: "pl",
                ts: "t"
            }
        };
        var s = {
            downlink: "do",
            effectiveType: "ef",
            rtt: "rtt",
            saveData: "sd"
        };
        var d = {
            devicePixelRatio: "dpr",
            screenHeight: "sh",
            screenWidth: "sw",
            viewportHeight: "vh",
            viewportWidth: "vw"
        };
        var f = {
            deviceMemory: "dm",
            hardwareConcurrency: "hc"
        };
        var l = {
            cumulativeLayoutShift: "cl",
            decodedBodySize: "db",
            domainLookup: "dml",
            domContentLoadedEventEnd: "de",
            domContentLoadedEventStart: "ds",
            encodedBodySize: "eb",
            firstContentfulPaint: "fcp",
            firstInputDelay: "fid",
            largestContentfulPaint: "lcp",
            loadEventEnd: "le",
            loadEventStart: "l",
            tcpConnection: "tcp",
            tlsConnection: "tls",
            timeToInteractive: "tti"
        };
        var p = {
            analyticsId: "aid",
            connection: {
                __encoding_config__: s,
                __encoding_key__: "con"
            },
            deliveryType: "dt",
            display: {
                __encoding_config__: d,
                __encoding_key__: "disp"
            },
            hardware: {
                __encoding_config__: f,
                __encoding_key__: "hdw"
            },
            hash: "h",
            hostname: "hn",
            marketingId: "mid",
            memberId: "mem",
            pathname: "p",
            version: "v"
        };
        var v = {
            accountId: "accountId",
            ampEnabled: "ampEnabled",
            authenticUrl: "authenticUrl",
            cloneable: "cloneable",
            collectionType: "collectionType",
            createdOn: "createdOn",
            developerMode: "developerMode",
            impersonatedSession: "impersonatedSession",
            inFrame: "inFrame",
            isHstsEnabled: "isHstsEnabled",
            isInternal: "isInternal",
            language: "language",
            memberId: "memberId",
            pageType: "pageType",
            platform: "platform",
            templateId: "templateId",
            timeZone: "timeZone",
            websiteId: "websiteId",
            websiteType: "websiteType"
        };
        var m = Object(r["a"])(Object(r["a"])({
            context: {
                __encoding_config__: v,
                __encoding_key__: "ctx"
            },
            supportLevel: "sl",
            visibilityStateOnDCL: "vs"
        }, p), l);
        var w = {
            duration: "d",
            endMarkDetail: "e",
            measureDetail: "m",
            name: "n",
            startMarkDetail: "s",
            startTime: "st"
        };
        var b = Object.keys(m);
        var h = Object.keys(w);
        var y = "mark";
        var g = "measure";
        var E = "DOMContentLoaded";
        var _ = "load";
        var S = "beforeunload";
        var O = "pagehide";
        var T = "rum-";
        var j = "SS_MID";
        var P = "SS_ANALYTICS_ID";
        var C = 3e4;
        var L = 3e4;
        var x = /(iPhone|iPod|iPad) OS ((1[0-2])|[2-9])_\d+.*AppleWebKit(?!.*Safari)/i
    },
    "./common/temp/node_modules/@sqs/rum-collector/lib/index.js": function(e, t, n) {
        "use strict";
        n.r(t);
        n.d(t, "default", function() {
            return Qe
        });
        n.d(t, "getPerformanceData", function() {
            return P
        });
        n.d(t, "getPerformanceMetrics", function() {
            return Ne
        });
        n.d(t, "mark", function() {
            return Ye["a"]
        });
        n.d(t, "measure", function() {
            return Ye["b"]
        });
        n.d(t, "getDomainLookup", function() {
            return V
        });
        n.d(t, "getTCPConnection", function() {
            return z
        });
        n.d(t, "getCumulativeLayoutShift", function() {
            return Ee
        });
        n.d(t, "getDecodedBodySize", function() {
            return _e
        });
        n.d(t, "getDomContentLoadedEventEnd", function() {
            return Se
        });
        n.d(t, "getDomContentLoadedEventStart", function() {
            return Oe
        });
        n.d(t, "getEncodedBodySize", function() {
            return Te
        });
        n.d(t, "getFirstContentfulPaint", function() {
            return je
        });
        n.d(t, "getFirstInputDelay", function() {
            return Pe
        });
        n.d(t, "getLargestContentfulPaint", function() {
            return Ce
        });
        n.d(t, "getLoadEventEnd", function() {
            return Le
        });
        n.d(t, "getLoadEventStart", function() {
            return xe
        });
        n.d(t, "getResponseStart", function() {
            return Re
        });
        n.d(t, "getTLSNegotiation", function() {
            return Ie
        });
        n.d(t, "getTimeToInteractive", function() {
            return Me
        });
        n.d(t, "trackLoadPerformance", function() {
            return $e
        });
        n.d(t, "trackEventsV2Factory", function() {
            return Je
        });
        var o = {};
        n.r(o);
        n.d(o, "getDomainLookup", function() {
            return V
        });
        n.d(o, "getTCPConnection", function() {
            return z
        });
        n.d(o, "getCumulativeLayoutShift", function() {
            return Ee
        });
        n.d(o, "getDecodedBodySize", function() {
            return _e
        });
        n.d(o, "getDomContentLoadedEventEnd", function() {
            return Se
        });
        n.d(o, "getDomContentLoadedEventStart", function() {
            return Oe
        });
        n.d(o, "getEncodedBodySize", function() {
            return Te
        });
        n.d(o, "getFirstContentfulPaint", function() {
            return je
        });
        n.d(o, "getFirstInputDelay", function() {
            return Pe
        });
        n.d(o, "getLargestContentfulPaint", function() {
            return Ce
        });
        n.d(o, "getLoadEventEnd", function() {
            return Le
        });
        n.d(o, "getLoadEventStart", function() {
            return xe
        });
        n.d(o, "getResponseStart", function() {
            return Re
        });
        n.d(o, "getTLSNegotiation", function() {
            return Ie
        });
        n.d(o, "getTimeToInteractive", function() {
            return Me
        });
        var s = n("./common/temp/node_modules/@sqs/rum-collector/node_modules/tslib/tslib.es6.js");
        var d = n("./common/temp/node_modules/@sqs/praetor/build/module/index.js");
        var i = n("./common/temp/node_modules/@sqs/rum-collector/lib/constants.js");

        function v(f, l) {
            var p = {};
            Object.keys(l).forEach(function(e) {
                var t = l[e];
                var n;
                var r;
                var o = f[e] || f;
                var i = typeof o;
                var a = "string" === i;
                var u = "object" === i || "undefined" === o;
                if (!a && !u) return;
                if (a) {
                    n = o;
                    r = m(t)
                } else {
                    var c = o.__encoding_skip__;
                    var s = o.__encoding_config__;
                    var d = o.__encoding_fn__;
                    if (!c && !s && !f) throw new Error("Invalid encoding map");
                    n = c ? e : o.__encoding_key__;
                    r = s ? v(s, t) : d ? d(t) : t
                }
                n && (p["" + n] = r)
            });
            return p
        }

        function m(e) {
            if ("boolean" === typeof e) return e ? 1 : 0;
            if (r(e)) return e.toString(36);
            return e
        }

        function r(e) {
            return ("number" === typeof e || e instanceof Number) && isFinite(e)
        }

        function a() {
            return !!(window.performance && window.performance.now && window.addEventListener)
        }

        function u() {
            return !!(window.PerformanceMeasure && window.PerformanceMark && window.performance && window.performance.mark && window.performance.measure)
        }

        function c() {
            if (!window.hasOwnProperty("PerformanceObserver")) return false;
            try {
                var e = new window.PerformanceObserver(function() {
                    return null
                });
                e.observe({
                    type: "mark"
                });
                e.disconnect()
            } catch (e) {
                return false
            }
            return true
        }

        function f() {
            return !!(window.performance && window.performance.getEntriesByType && window.PerformanceNavigationTiming)
        }

        function l() {
            return !!(window.performance && window.performance.timing && window.PerformanceTiming)
        }

        function p() {
            return "function" === typeof window.navigator.sendBeacon && !i["e"].test(window.navigator.userAgent)
        }

        function w() {
            return !!window.PerformancePaintTiming
        }

        function b() {
            return !!window.LargestContentfulPaint
        }

        function h() {
            return !!window.PerformanceLongTaskTiming
        }
        var y;
        var g = [];
        var E = function(e) {
            g.push(e)
        };

        function _(e, t) {
            if (p() && navigator.sendBeacon(e, t)) return;
            var n = new XMLHttpRequest;
            n.open("POST", e, true);
            n.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
            n.send(t)
        }

        function S() {
            if (g.length) {
                var e = JSON.stringify(g);
                _(i["n"] + i["o"], e);
                g = []
            }
        }

        function O() {
            window.addEventListener(i["f"], function() {
                y = window.setTimeout(S, i["b"])
            });
            window.addEventListener(i["j"], S);
            window.addEventListener(i["c"], function() {
                window.clearTimeout(y);
                S()
            })
        }

        function T(e, t) {
            var n = v(e, t);
            if (!n) throw new Error("Data is empty");
            E(n)
        }
        var j = [];

        function P() {
            return j
        }

        function C(e) {
            j.push(e)
        }

        function L(e, t, n, r) {
            var o = Object.freeze({
                app: e,
                data: r,
                event: t,
                pageLoadId: n,
                ts: Date.now()
            });
            C(o);
            return o
        }
        var x = function(o) {
            return function(e, t) {
                void 0 === t && (t = false);
                var n = o.getABTestVariant(e + "-rollout", t.toString()).variant;
                var r = "true" === n;
                return r
            }
        };
        var R = function(o, i) {
            return function(e, t, n) {
                var r = L(o, t, i, e);
                T(n, r)
            }
        };
        var I = function() {
            return new Promise(function(e, t) {
                var n = new XMLHttpRequest;
                n.onreadystatechange = function() {
                    if (n.readyState === XMLHttpRequest.DONE)
                        if (200 === n.status) try {
                            e(JSON.parse(n.response))
                        } catch (e) {
                            t(e)
                        } else 0 !== n.status && t(new Error("XHR request DONE with unexpected status: " + n.status))
                };
                n.ontimeout = function() {
                    t(new Error("Metric settings request timeout"))
                };
                n.open("GET", i["n"] + i["p"], true);
                n.timeout = i["m"];
                n.send()
            })
        };
        var A = function(n) {
            return function(e, t) {
                n && n(e, t)
            }
        };
        var M = function(e) {
            var t = {
                appName: e.appName || "",
                context: e.context || {},
                enabled: "boolean" !== typeof e.enabled || e.enabled
            };
            t.captureException = A(e.captureException);
            return t
        };

        function N(e) {
            var t = {};
            for (var n in e) "function" !== typeof e[n] && (t[n] = e[n]);
            return t
        }
        var D = function(e) {
            var n = e.type,
                t = e.buffered,
                r = void 0 === t || t,
                o = e.isReadyFn,
                i = void 0 === o ? function() {
                    return true
                } : o;
            return new Promise(function(t) {
                var e = new PerformanceObserver(function(e) {
                    i(e) && t(e)
                });
                e.observe({
                    type: n,
                    buffered: r
                })
            })
        };

        function k() {
            var e = {};
            if (window.performance) {
                if (f()) {
                    e = N(window.performance.getEntriesByType("navigation")[0]);
                    e.supportLevel = 2
                } else if (l()) {
                    e = N(window.performance.timing);
                    e.supportLevel = 1
                }
                if (performance.navigation) {
                    e.navigationType = window.performance.navigation.type;
                    e.redirectCount = window.performance.navigation.redirectCount
                }
            }
            return e
        }
        var F = null;
        var B = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            if (!!F) return [3, 4];
                            if (!(f() && c())) return [3, 2];
                            return [4, U()];
                        case 1:
                            F = e.sent();
                            return [3, 4];
                        case 2:
                            if (!l()) return [3, 4];
                            return [4, H()];
                        case 3:
                            F = e.sent();
                            e.label = 4;
                        case 4:
                            return [2, F]
                    }
                })
            })
        };
        var q = function(n) {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, B()];
                        case 1:
                            t = e.sent();
                            if (!t || "number" !== typeof t[n]) return [2, null];
                            return [2, Math.round(t[n])]
                    }
                })
            })
        };

        function U() {
            return Object(s["b"])(this, void 0, void 0, function() {
                var t, n, r;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            e.trys.push([0, 2, , 3]);
                            return [4, D({
                                type: "navigation",
                                isReadyFn: function(e) {
                                    var t = e.getEntries()[0];
                                    return !!(t.duration && t.duration > 0)
                                }
                            })];
                        case 1:
                            t = e.sent();
                            n = t.getEntries()[0];
                            return [2, N(n)];
                        case 2:
                            r = e.sent();
                            return [2, null];
                        case 3:
                            return [2]
                    }
                })
            })
        }

        function H() {
            var t = function() {
                var e = N(window.performance.timing);
                var t = e.navigationStart;
                delete e.navigationStart;
                for (var n in e) e[n] > 0 && (e[n] = e[n] - t);
                return e
            };
            return new Promise(function(e) {
                "complete" !== document.readyState ? window.addEventListener("load", function() {
                    setTimeout(function() {
                        e(t())
                    })
                }) : e(t())
            })
        }
        var V = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t, n, r, o;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, Promise.all([q("domainLookupEnd"), q("domainLookupStart")])];
                        case 1:
                            t = e.sent(), n = t[0], r = t[1];
                            if (!(n && r)) return [2, null];
                            o = n - r;
                            return [2, {
                                domainLookup: o
                            }]
                    }
                })
            })
        };
        var z = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t, n, r, o;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, Promise.all([q("connectEnd"), q("connectStart")])];
                        case 1:
                            t = e.sent(), n = t[0], r = t[1];
                            if (!(n && r)) return [2, null];
                            o = n - r;
                            return [2, {
                                tcpConnection: o
                            }]
                    }
                })
            })
        };
        var G, X, W, Q, Y = function(e, t) {
                return {
                    name: e,
                    value: void 0 === t ? -1 : t,
                    delta: 0,
                    entries: [],
                    id: "v1-".concat(Date.now(), "-").concat(Math.floor(8999999999999 * Math.random()) + 1e12)
                }
            },
            K = function(e, t) {
                try {
                    if (PerformanceObserver.supportedEntryTypes.includes(e)) {
                        var n = new PerformanceObserver(function(e) {
                            return e.getEntries().map(t)
                        });
                        return n.observe({
                            type: e,
                            buffered: !0
                        }), n
                    }
                } catch (e) {}
            },
            Z = function(n, r) {
                var e = function e(t) {
                    "pagehide" !== t.type && "hidden" !== document.visibilityState || (n(t), r && (removeEventListener("visibilitychange", e, !0), removeEventListener("pagehide", e, !0)))
                };
                addEventListener("visibilitychange", e, !0), addEventListener("pagehide", e, !0)
            },
            J = function(t) {
                addEventListener("pageshow", function(e) {
                    e.persisted && t(e)
                }, !0)
            },
            $ = "function" == typeof WeakSet ? new WeakSet : new Set,
            ee = function(e, t, n) {
                var r;
                return function() {
                    t.value >= 0 && (n || $.has(t) || "hidden" === document.visibilityState) && (t.delta = t.value - (r || 0), (t.delta || void 0 === r) && (r = t.value, e(t)))
                }
            },
            te = function(e, t) {
                var n, r = Y("CLS", 0),
                    o = function(e) {
                        e.hadRecentInput || (r.value += e.value, r.entries.push(e), n())
                    },
                    i = K("layout-shift", o);
                i && (n = ee(e, r, t), Z(function() {
                    i.takeRecords().map(o), n()
                }), J(function() {
                    r = Y("CLS", 0), n = ee(e, r, t)
                }))
            },
            ne = -1,
            re = function() {
                return "hidden" === document.visibilityState ? 0 : 1 / 0
            },
            oe = function() {
                Z(function(e) {
                    var t = e.timeStamp;
                    ne = t
                }, !0)
            },
            ie = function() {
                return ne < 0 && (ne = re(), oe(), J(function() {
                    setTimeout(function() {
                        ne = re(), oe()
                    }, 0)
                })), {
                    get timeStamp() {
                        return ne
                    }
                }
            },
            ae = function(t, n) {
                var r, o = ie(),
                    i = Y("FCP"),
                    a = K("paint", function(e) {
                        "first-contentful-paint" === e.name && (a && a.disconnect(), e.startTime < o.timeStamp && (i.value = e.startTime, i.entries.push(e), $.add(i), r()))
                    });
                a && (r = ee(t, i, n), J(function(e) {
                    i = Y("FCP"), r = ee(t, i, n), requestAnimationFrame(function() {
                        requestAnimationFrame(function() {
                            i.value = performance.now() - e.timeStamp, $.add(i), r()
                        })
                    })
                }))
            },
            ue = {
                passive: !0,
                capture: !0
            },
            ce = new Date,
            se = function(e, t) {
                G || (G = t, X = e, W = new Date, le(removeEventListener), de())
            },
            de = function() {
                if (X >= 0 && X < W - ce) {
                    var t = {
                        entryType: "first-input",
                        name: G.type,
                        target: G.target,
                        cancelable: G.cancelable,
                        startTime: G.timeStamp,
                        processingStart: G.timeStamp + X
                    };
                    Q.forEach(function(e) {
                        e(t)
                    }), Q = []
                }
            },
            fe = function(e) {
                if (e.cancelable) {
                    var t = (e.timeStamp > 1e12 ? new Date : performance.now()) - e.timeStamp;
                    "pointerdown" == e.type ? function(e, t) {
                        var n = function() {
                                se(e, t), o()
                            },
                            r = function() {
                                o()
                            },
                            o = function() {
                                removeEventListener("pointerup", n, ue), removeEventListener("pointercancel", r, ue)
                            };
                        addEventListener("pointerup", n, ue), addEventListener("pointercancel", r, ue)
                    }(t, e) : se(t, e)
                }
            },
            le = function(t) {
                ["mousedown", "keydown", "touchstart", "pointerdown"].forEach(function(e) {
                    return t(e, fe, ue)
                })
            },
            pe = function(t, n) {
                var r, o = ie(),
                    i = Y("FID"),
                    a = function(e) {
                        e.startTime < o.timeStamp && (i.value = e.processingStart - e.startTime, i.entries.push(e), $.add(i), r())
                    },
                    e = K("first-input", a);
                r = ee(t, i, n), e && Z(function() {
                    e.takeRecords().map(a), e.disconnect()
                }, !0), e && J(function() {
                    var e;
                    i = Y("FID"), r = ee(t, i, n), Q = [], X = -1, G = null, le(addEventListener), e = a, Q.push(e), de()
                })
            },
            ve = function(t, n) {
                var r, o = ie(),
                    i = Y("LCP"),
                    e = function(e) {
                        var t = e.startTime;
                        t < o.timeStamp && (i.value = t, i.entries.push(e)), r()
                    },
                    a = K("largest-contentful-paint", e);
                if (a) {
                    r = ee(t, i, n);
                    var u = function() {
                        $.has(i) || (a.takeRecords().map(e), a.disconnect(), $.add(i), r())
                    };
                    ["keydown", "click"].forEach(function(e) {
                        addEventListener(e, u, {
                            once: !0,
                            capture: !0
                        })
                    }), Z(u, !0), J(function(e) {
                        i = Y("LCP"), r = ee(t, i, n), requestAnimationFrame(function() {
                            requestAnimationFrame(function() {
                                i.value = performance.now() - e.timeStamp, $.add(i), r()
                            })
                        })
                    })
                }
            },
            me = function(t) {
                var e, n = Y("TTFB");
                e = function() {
                    try {
                        var e = performance.getEntriesByType("navigation")[0] || function() {
                            var e = performance.timing,
                                t = {
                                    entryType: "navigation",
                                    startTime: 0
                                };
                            for (var n in e) "navigationStart" !== n && "toJSON" !== n && (t[n] = Math.max(e[n] - e.navigationStart, 0));
                            return t
                        }();
                        n.value = n.delta = e.responseStart, n.entries = [e], t(n)
                    } catch (e) {}
                }, "complete" === document.readyState ? setTimeout(e, 0) : addEventListener("pageshow", e)
            };
        var we = function(e) {
            return new Promise(function(t, n) {
                try {
                    e(function(e) {
                        t(e)
                    })
                } catch (e) {
                    n(e)
                }
            })
        };
        var be = function(t, n) {
            void 0 === n && (n = null);
            return new Promise(function(e) {
                setTimeout(function() {
                    return e(n)
                }, t)
            })
        };
        var he = 6e4;
        var ye = function(t) {
            return function() {
                return Object(s["b"])(void 0, void 0, void 0, function() {
                    return Object(s["c"])(this, function(e) {
                        return [2, Promise.race([we(t), be(he)])]
                    })
                })
            }
        };
        var ge = {
            getCLS: ye(te),
            getFCP: ye(ae),
            getLCP: ye(ve),
            getTTFB: ye(me),
            getFID: ye(pe)
        };
        var Ee = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, ge.getCLS()];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                cumulativeLayoutShift: t.value
                            } : null]
                    }
                })
            })
        };
        var _e = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, q("decodedBodySize")];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                decodedBodySize: t
                            } : null]
                    }
                })
            })
        };
        var Se = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, q("domContentLoadedEventEnd")];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                domContentLoadedEventEnd: t
                            } : null]
                    }
                })
            })
        };
        var Oe = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, q("domContentLoadedEventStart")];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                domContentLoadedEventStart: t
                            } : null]
                    }
                })
            })
        };
        var Te = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, q("encodedBodySize")];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                encodedBodySize: t
                            } : null]
                    }
                })
            })
        };
        var je = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, ge.getFCP()];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                firstContentfulPaint: Math.round(t.value)
                            } : null]
                    }
                })
            })
        };
        var Pe = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, ge.getFID()];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                firstInputDelay: Math.round(t.value)
                            } : null]
                    }
                })
            })
        };
        var Ce = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, ge.getLCP()];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                largestContentfulPaint: Math.round(t.value)
                            } : null]
                    }
                })
            })
        };
        var Le = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, q("loadEventEnd")];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                loadEventEnd: t
                            } : null]
                    }
                })
            })
        };
        var xe = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, q("loadEventStart")];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                loadEventStart: t
                            } : null]
                    }
                })
            })
        };
        var Re = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, ge.getTTFB()];
                        case 1:
                            t = e.sent();
                            return [2, t ? {
                                responseStart: Math.round(t.value)
                            } : null]
                    }
                })
            })
        };
        var Ie = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t, n, r, o;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, Promise.all([q("connectEnd"), q("secureConnectionStart")])];
                        case 1:
                            t = e.sent(), n = t[0], r = t[1];
                            if (!(n && r)) return [2, null];
                            o = n - r;
                            return [2, {
                                tlsNegotiation: o
                            }]
                    }
                })
            })
        };
        var Ae = n("./common/temp/node_modules/tti-polyfill/tti-polyfill.js");
        var Me = function() {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    if (!(h() && c())) return [2, null];
                    t = false;
                    window.__tti = {
                        e: []
                    };
                    D({
                        type: "longtask",
                        buffered: false,
                        isReadyFn: function(e) {
                            window.__tti.e = window.__tti.e.concat(e.getEntries());
                            return t
                        }
                    });
                    return [2, Object(Ae["getFirstConsistentlyInteractive"])().then(function(e) {
                        t = true;
                        return {
                            timeToInteractive: Math.round(e)
                        }
                    })]
                })
            })
        };

        function Ne() {
            return Object(s["b"])(this, void 0, void 0, function() {
                var t, n, r;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            t = Object.values(o).map(function(e) {
                                return e()
                            });
                            e.label = 1;
                        case 1:
                            e.trys.push([1, 3, , 4]);
                            return [4, Promise.all(t)];
                        case 2:
                            n = e.sent().reduce(function(e, t) {
                                e = Object(s["a"])(Object(s["a"])({}, e), t);
                                return e
                            }, {});
                            return [2, n];
                        case 3:
                            r = e.sent();
                            return [2, {}];
                        case 4:
                            return [2]
                    }
                })
            })
        }

        function De(e) {
            var t = new RegExp("(^| )" + e + "=([^;]+)");
            var n = document.cookie.match(t);
            if (n) return n[2];
            return ""
        }
        var ke;
        (function(e) {
            e["Beacon"] = "beacon";
            e["XHR"] = "xhr"
        })(ke = ke || {});

        function Fe() {
            var e = Be();
            var t = qe();
            var n = He();
            return {
                analyticsId: De(i["a"]),
                connection: e,
                deliveryType: p() ? ke.Beacon : ke.XHR,
                display: t,
                hardware: n,
                hash: window.location.hash || "",
                hostname: window.location.hostname || "",
                marketingId: De(i["h"]),
                memberId: Ue(),
                pathname: window.location.pathname || "/",
                version: i["q"]
            }
        }

        function Be() {
            var e = {};
            var t = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
            if (t) {
                var n = (1e3 * t.downlink).toString();
                e = {
                    downlink: parseInt(n, 10),
                    effectiveType: t.effectiveType,
                    rtt: t.rtt,
                    saveData: t.saveData
                }
            }
            return e
        }

        function qe() {
            var e = window.devicePixelRatio;
            var t = window.screen,
                n = t.width,
                r = t.height;
            var o = document.documentElement,
                i = o.clientHeight,
                a = o.clientWidth;
            var u = {
                devicePixelRatio: e,
                screenHeight: r,
                screenWidth: n,
                viewportHeight: i,
                viewportWidth: a
            };
            return u
        }

        function Ue() {
            try {
                return window.Static.SQUARESPACE_CONTEXT.authenticatedAccount.id
            } catch (e) {
                return ""
            }
        }

        function He() {
            return {
                deviceMemory: navigator.deviceMemory,
                hardwareConcurrency: navigator.hardwareConcurrency
            }
        }
        var Ve = function(o) {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var n, t, r;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            n = Object(s["a"])({
                                context: o
                            }, Fe());
                            window.addEventListener(i["d"], function() {
                                return n.visibilityStateOnDCL = document.visibilityState || ""
                            });
                            return [4, Ne()];
                        case 1:
                            t = e.sent();
                            n = Object(s["a"])(Object(s["a"])({}, n), t);
                            r = i["l"].reduce(function(e, t) {
                                n.hasOwnProperty(t) && (e[t] = n[t]);
                                return e
                            }, {});
                            return [2, r]
                    }
                })
            })
        };
        var ze = function(n, r) {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, Ve(r)];
                        case 1:
                            t = e.sent();
                            n(t, "page_speed", Object(i["s"])(i["k"]));
                            return [2]
                    }
                })
            })
        };

        function Ge(e) {
            return "string" === typeof e && e.substring(0, 4) === i["r"]
        }
        var Xe = new Set;
        var We = function(n) {
            if (!u()) return;
            var t = function(e) {
                var t = e.map(N);
                t.forEach(function(e) {
                    if (!Ge(e.name)) return;
                    var t = e.name + "|" + e.duration;
                    if (!Xe.has(t)) {
                        n(e, "user", Object(i["s"])(i["t"]));
                        Xe.add(t)
                    }
                })
            };
            t(window.performance.getEntriesByType(i["i"]));
            if (c()) {
                var e = new window.PerformanceObserver(function(e) {
                    return t(e.getEntries())
                });
                e.observe({
                    type: i["i"]
                })
            } else window.addEventListener(i["c"], function() {
                t(window.performance.getEntriesByType(i["i"]))
            })
        };

        function Qe(c) {
            return Object(s["b"])(this, void 0, void 0, function() {
                var t, n, r, o, i, a, u;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            t = M(c);
                            if (!t.enabled) return [2];
                            n = "";
                            e.label = 1;
                        case 1:
                            e.trys.push([1, 3, , 4]);
                            return [4, I()];
                        case 2:
                            r = e.sent();
                            n = r.pageLoadId;
                            if (!n) throw new Error("Unable to resolve pageLoadId");
                            o = new d["StaticPraetorClient"](r);
                            i = x(o);
                            if (["rum", t.appName + "-app"].some(function(e) {
                                    return !i(e)
                                })) return [2];
                            a = R(t.appName, n);
                            i("track-page-speed") && ze(a, t.context);
                            i("track-user-timing") && We(a);
                            O();
                            return [3, 4];
                        case 3:
                            u = e.sent();
                            t.captureException(u, {
                                pageLoadId: n,
                                parsedOptions: t
                            });
                            return [3, 4];
                        case 4:
                            return [2]
                    }
                })
            })
        }
        var Ye = n("./common/temp/node_modules/@sqs/rum-collector/lib/timing.js");
        var Ke = {
            action: "load",
            actor: "user",
            event_owner_team: "web_performance",
            event_source: "web",
            object_type: "website"
        };
        var Ze = function() {
            var e = /^qa\d+.sqsp.net/g;
            var t = /^stage.sqsp.net/g;
            var n = /(dev.squarespace.net|localhost|127.0.0.1|0.0.0.0)/g;
            var r = window.location.hostname.substr(window.location.hostname.indexOf(".") + 1);
            if (t.test(r) || e.test(r)) return "staging";
            if (n.test(r)) return "dev";
            return "prod"
        };
        var Je = function(e, t) {
            void 0 === t && (t = Ze());
            return new e({
                customSchemaName: "Performance",
                sourceEnvironment: t
            }, Ke)
        };
        var $e = function(n) {
            return Object(s["b"])(void 0, void 0, void 0, function() {
                var t;
                return Object(s["c"])(this, function(e) {
                    switch (e.label) {
                        case 0:
                            return [4, Ne()];
                        case 1:
                            t = e.sent();
                            n({
                                cumulative_layout_shift: t.cumulativeLayoutShift,
                                decoded_body_size_bytes: t.decodedBodySize,
                                dom_content_loaded_event_end_ms: t.domContentLoadedEventEnd,
                                dom_content_loaded_event_start_ms: t.domContentLoadedEventStart,
                                domain_lookup_ms: t.domainLookup,
                                encoded_body_size_bytes: t.encodedBodySize,
                                first_contentful_paint_ms: t.firstContentfulPaint,
                                first_input_delay_ms: t.firstInputDelay,
                                largest_contentful_paint_ms: t.largestContentfulPaint,
                                load_event_end_ms: t.loadEventEnd,
                                load_event_start_ms: t.loadEventStart,
                                response_start_ms: t.responseStart,
                                tcp_connection_ms: t.tcpConnection,
                                time_to_interactive_ms: t.timeToInteractive,
                                tls_negotiation_ms: t.tlsNegotiation
                            });
                            return [2]
                    }
                })
            })
        }
    },
    "./common/temp/node_modules/@sqs/rum-collector/lib/timing.js": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        n.d(t, "b", function() {
            return o
        });
        var i = n("./common/temp/node_modules/@sqs/rum-collector/lib/constants.js");
        var a = function(e) {
            var t;
            "function" === typeof(null === (t = null === window || void 0 === window ? void 0 : window.SQUARESPACE_SENTRY) || void 0 === t ? void 0 : t.captureException) ? window.SQUARESPACE_SENTRY.captureException(e): console.warn("RUM timing error: " + e)
        };

        function r(e, t) {
            try {
                if (!c()) return;
                var n = i["r"] + e;
                window.performance.mark(n, t)
            } catch (e) {
                a(e)
            }
        }

        function o(e, t) {
            void 0 === t && (t = {
                requireStart: false
            });
            try {
                if (!(c() && u())) return;
                var n = i["r"] + e;
                var r = {
                    detail: t.detail,
                    duration: t.duration
                };
                void 0 === t.start ? r.start = n : "string" === typeof t.start ? r.start = i["r"] + t.start : r.start = t.start;
                r.end = "string" === typeof t.end ? i["r"] + t.end : t.end;
                if (t.requireStart && ("number" === typeof r.start || 0 === window.performance.getEntriesByName(r.start, i["g"]).length)) return;
                d(n, r);
                var o = s(n);
                return o
            } catch (e) {
                a(e)
            }
        }

        function u() {
            return "performance" in window && "getEntries" in window.performance && "getEntriesByType" in window.performance && "getEntriesByName" in window.performance
        }

        function c() {
            return i["g"] in window.performance && i["i"] in window.performance
        }

        function s(e) {
            var t = window.performance.getEntriesByName(e, i["i"]);
            return t[t.length - 1]
        }

        function d(t, n) {
            try {
                window.performance.measure(t, n)
            } catch (e) {
                var r = "string" === typeof n.start ? n.start : t;
                var o = "string" === typeof n.end ? n.end : void 0;
                try {
                    window.performance.measure(t, r, o)
                } catch (e) {
                    if (!(e instanceof DOMException)) throw e;
                    try {
                        window.performance.measure(t, "navigationStart")
                    } catch (e) {
                        if (!(e instanceof DOMException)) throw e;
                        window.performance.measure(t)
                    }
                }
            }
        }
    },
    "./common/temp/node_modules/@sqs/rum-collector/node_modules/tslib/tslib.es6.js": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        n.d(t, "b", function() {
            return d
        });
        n.d(t, "c", function() {
            return f
        });
        var r = function(e, t) {
            r = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(e, t) {
                e.__proto__ = t
            } || function(e, t) {
                for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
            };
            return r(e, t)
        };

        function o(e, t) {
            if ("function" !== typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
            r(e, t);

            function n() {
                this.constructor = e
            }
            e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
        }
        var i = function() {
            i = Object.assign || function e(t) {
                for (var n, r = 1, o = arguments.length; r < o; r++) {
                    n = arguments[r];
                    for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i])
                }
                return t
            };
            return i.apply(this, arguments)
        };

        function a(e, t) {
            var n = {};
            for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
            if (null != e && "function" === typeof Object.getOwnPropertySymbols)
                for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) t.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
            return n
        }

        function u(e, t, n, r) {
            var o = arguments.length,
                i = o < 3 ? t : null === r ? r = Object.getOwnPropertyDescriptor(t, n) : r,
                a;
            if ("object" === typeof Reflect && "function" === typeof Reflect.decorate) i = Reflect.decorate(e, t, n, r);
            else
                for (var u = e.length - 1; u >= 0; u--)(a = e[u]) && (i = (o < 3 ? a(i) : o > 3 ? a(t, n, i) : a(t, n)) || i);
            return o > 3 && i && Object.defineProperty(t, n, i), i
        }

        function c(n, r) {
            return function(e, t) {
                r(e, t, n)
            }
        }

        function s(e, t) {
            if ("object" === typeof Reflect && "function" === typeof Reflect.metadata) return Reflect.metadata(e, t)
        }

        function d(e, a, n, u) {
            function c(t) {
                return t instanceof n ? t : new n(function(e) {
                    e(t)
                })
            }
            return new(n = n || Promise)(function(t, n) {
                function r(e) {
                    try {
                        i(u.next(e))
                    } catch (e) {
                        n(e)
                    }
                }

                function o(e) {
                    try {
                        i(u["throw"](e))
                    } catch (e) {
                        n(e)
                    }
                }

                function i(e) {
                    e.done ? t(e.value) : c(e.value).then(r, o)
                }
                i((u = u.apply(e, a || [])).next())
            })
        }

        function f(e, n) {
            var r = {
                    label: 0,
                    sent: function() {
                        if (1 & a[0]) throw a[1];
                        return a[1]
                    },
                    trys: [],
                    ops: []
                },
                o, i, a, t;
            return t = {
                next: u(0),
                throw: u(1),
                return: u(2)
            }, "function" === typeof Symbol && (t[Symbol.iterator] = function() {
                return this
            }), t;

            function u(t) {
                return function(e) {
                    return c([t, e])
                }
            }

            function c(t) {
                if (o) throw new TypeError("Generator is already executing.");
                while (r) try {
                    if (o = 1, i && (a = 2 & t[0] ? i["return"] : t[0] ? i["throw"] || ((a = i["return"]) && a.call(i), 0) : i.next) && !(a = a.call(i, t[1])).done) return a;
                    (i = 0, a) && (t = [2 & t[0], a.value]);
                    switch (t[0]) {
                        case 0:
                        case 1:
                            a = t;
                            break;
                        case 4:
                            r.label++;
                            return {
                                value: t[1],
                                done: false
                            };
                        case 5:
                            r.label++;
                            i = t[1];
                            t = [0];
                            continue;
                        case 7:
                            t = r.ops.pop();
                            r.trys.pop();
                            continue;
                        default:
                            if (!(a = r.trys, a = a.length > 0 && a[a.length - 1]) && (6 === t[0] || 2 === t[0])) {
                                r = 0;
                                continue
                            }
                            if (3 === t[0] && (!a || t[1] > a[0] && t[1] < a[3])) {
                                r.label = t[1];
                                break
                            }
                            if (6 === t[0] && r.label < a[1]) {
                                r.label = a[1];
                                a = t;
                                break
                            }
                            if (a && r.label < a[2]) {
                                r.label = a[2];
                                r.ops.push(t);
                                break
                            }
                            a[2] && r.ops.pop();
                            r.trys.pop();
                            continue
                    }
                    t = n.call(e, r)
                } catch (e) {
                    t = [6, e];
                    i = 0
                } finally {
                    o = a = 0
                }
                if (5 & t[0]) throw t[1];
                return {
                    value: t[0] ? t[1] : void 0,
                    done: true
                }
            }
        }
        var l = Object.create ? function(e, t, n, r) {
            void 0 === r && (r = n);
            Object.defineProperty(e, r, {
                enumerable: true,
                get: function() {
                    return t[n]
                }
            })
        } : function(e, t, n, r) {
            void 0 === r && (r = n);
            e[r] = t[n]
        };

        function p(e, t) {
            for (var n in e) "default" === n || Object.prototype.hasOwnProperty.call(t, n) || l(t, e, n)
        }

        function v(e) {
            var t = "function" === typeof Symbol && Symbol.iterator,
                n = t && e[t],
                r = 0;
            if (n) return n.call(e);
            if (e && "number" === typeof e.length) return {
                next: function() {
                    e && r >= e.length && (e = void 0);
                    return {
                        value: e && e[r++],
                        done: !e
                    }
                }
            };
            throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
        }

        function m(e, t) {
            var n = "function" === typeof Symbol && e[Symbol.iterator];
            if (!n) return e;
            var r = n.call(e),
                o, i = [],
                a;
            try {
                while ((void 0 === t || t-- > 0) && !(o = r.next()).done) i.push(o.value)
            } catch (e) {
                a = {
                    error: e
                }
            } finally {
                try {
                    o && !o.done && (n = r["return"]) && n.call(r)
                } finally {
                    if (a) throw a.error
                }
            }
            return i
        }

        function w() {
            for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(m(arguments[t]));
            return e
        }

        function b() {
            for (var e = 0, t = 0, n = arguments.length; t < n; t++) e += arguments[t].length;
            for (var r = Array(e), o = 0, t = 0; t < n; t++)
                for (var i = arguments[t], a = 0, u = i.length; a < u; a++, o++) r[o] = i[a];
            return r
        }

        function h(e, t) {
            for (var n = 0, r = t.length, o = e.length; n < r; n++, o++) e[o] = t[n];
            return e
        }

        function y(e) {
            return this instanceof y ? (this.v = e, this) : new y(e)
        }

        function g(e, t, n) {
            if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
            var o = n.apply(e, t || []),
                i, a = [];
            return i = {}, r("next"), r("throw"), r("return"), i[Symbol.asyncIterator] = function() {
                return this
            }, i;

            function r(r) {
                o[r] && (i[r] = function(n) {
                    return new Promise(function(e, t) {
                        a.push([r, n, e, t]) > 1 || u(r, n)
                    })
                })
            }

            function u(e, t) {
                try {
                    c(o[e](t))
                } catch (e) {
                    f(a[0][3], e)
                }
            }

            function c(e) {
                e.value instanceof y ? Promise.resolve(e.value.v).then(s, d) : f(a[0][2], e)
            }

            function s(e) {
                u("next", e)
            }

            function d(e) {
                u("throw", e)
            }

            function f(e, t) {
                (e(t), a.shift(), a.length) && u(a[0][0], a[0][1])
            }
        }

        function E(r) {
            var e, o;
            return e = {}, t("next"), t("throw", function(e) {
                throw e
            }), t("return"), e[Symbol.iterator] = function() {
                return this
            }, e;

            function t(t, n) {
                e[t] = r[t] ? function(e) {
                    return (o = !o) ? {
                        value: y(r[t](e)),
                        done: "return" === t
                    } : n ? n(e) : e
                } : n
            }
        }

        function _(o) {
            if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
            var e = o[Symbol.asyncIterator],
                t;
            return e ? e.call(o) : (o = "function" === typeof v ? v(o) : o[Symbol.iterator](), t = {}, n("next"), n("throw"), n("return"), t[Symbol.asyncIterator] = function() {
                return this
            }, t);

            function n(r) {
                t[r] = o[r] && function(n) {
                    return new Promise(function(e, t) {
                        n = o[r](n), i(e, t, n.done, n.value)
                    })
                }
            }

            function i(t, e, n, r) {
                Promise.resolve(r).then(function(e) {
                    t({
                        value: e,
                        done: n
                    })
                }, e)
            }
        }

        function S(e, t) {
            Object.defineProperty ? Object.defineProperty(e, "raw", {
                value: t
            }) : e.raw = t;
            return e
        }
        var O = Object.create ? function(e, t) {
            Object.defineProperty(e, "default", {
                enumerable: true,
                value: t
            })
        } : function(e, t) {
            e["default"] = t
        };

        function T(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e)
                for (var n in e) "default" !== n && Object.prototype.hasOwnProperty.call(e, n) && l(t, e, n);
            O(t, e);
            return t
        }

        function j(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function P(e, t, n, r) {
            if ("a" === n && !r) throw new TypeError("Private accessor was defined without a getter");
            if ("function" === typeof t ? e !== t || !r : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
            return "m" === n ? r : "a" === n ? r.call(e) : r ? r.value : t.get(e)
        }

        function C(e, t, n, r, o) {
            if ("m" === r) throw new TypeError("Private method is not writable");
            if ("a" === r && !o) throw new TypeError("Private accessor was defined without a setter");
            if ("function" === typeof t ? e !== t || !o : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
            return "a" === r ? o.call(e, n) : o ? o.value = n : t.set(e, n), n
        }
    },
    "./common/temp/node_modules/tti-polyfill/tti-polyfill.js": function(T, j, e) {
        (function(_) {
            var S, O;
            (function() {
                var t = "undefined" != typeof window && window === this ? this : "undefined" != typeof _ && null != _ ? _ : this,
                    n = "function" == typeof Object.defineProperties ? Object.defineProperty : function(e, t, n) {
                        e != Array.prototype && e != Object.prototype && (e[t] = n.value)
                    };

                function r() {
                    r = function() {};
                    t.Symbol || (t.Symbol = e)
                }
                var o = 0;

                function e(e) {
                    return "jscomp_symbol_" + (e || "") + o++
                }

                function i() {
                    r();
                    var e = t.Symbol.iterator;
                    e = e || (t.Symbol.iterator = t.Symbol("iterator"));
                    "function" != typeof Array.prototype[e] && n(Array.prototype, e, {
                        configurable: !0,
                        writable: !0,
                        value: function() {
                            return a(this)
                        }
                    });
                    i = function() {}
                }

                function a(e) {
                    var t = 0;
                    return u(function() {
                        return t < e.length ? {
                            done: !1,
                            value: e[t++]
                        } : {
                            done: !0
                        }
                    })
                }

                function u(e) {
                    i();
                    e = {
                        next: e
                    };
                    e[t.Symbol.iterator] = function() {
                        return this
                    };
                    return e
                }

                function c(e) {
                    i();
                    var t = e[Symbol.iterator];
                    return t ? t.call(e) : a(e)
                }

                function s(e) {
                    if (!(e instanceof Array)) {
                        e = c(e);
                        for (var t, n = []; !(t = e.next()).done;) n.push(t.value);
                        e = n
                    }
                    return e
                }
                var d = 0;

                function f(o, i) {
                    var a = XMLHttpRequest.prototype.send,
                        u = d++;
                    XMLHttpRequest.prototype.send = function(e) {
                        for (var t = [], n = 0; n < arguments.length; ++n) t[n - 0] = arguments[n];
                        var r = this;
                        o(u);
                        this.addEventListener("readystatechange", function() {
                            4 === r.readyState && i(u)
                        });
                        return a.apply(this, t)
                    }
                }

                function l(i, a) {
                    var u = fetch;
                    fetch = function(e) {
                        for (var o = [], t = 0; t < arguments.length; ++t) o[t - 0] = arguments[t];
                        return new Promise(function(t, n) {
                            var r = d++;
                            i(r);
                            u.apply(null, [].concat(s(o))).then(function(e) {
                                a(r);
                                t(e)
                            }, function(e) {
                                a(e);
                                n(e)
                            })
                        })
                    }
                }
                var p = "img script iframe link audio video source".split(" ");

                function v(e, t) {
                    e = c(e);
                    for (var n = e.next(); !n.done; n = e.next())
                        if (n = n.value, t.includes(n.nodeName.toLowerCase()) || v(n.children, t)) return !0;
                    return !1
                }

                function m(n) {
                    var e = new MutationObserver(function(e) {
                        e = c(e);
                        for (var t = e.next(); !t.done; t = e.next()) t = t.value, "childList" == t.type && v(t.addedNodes, p) ? n(t) : "attributes" == t.type && p.includes(t.target.tagName.toLowerCase()) && n(t)
                    });
                    e.observe(document, {
                        attributes: !0,
                        childList: !0,
                        subtree: !0,
                        attributeFilter: ["href", "src"]
                    });
                    return e
                }

                function w(e, t) {
                    if (2 < e.length) return performance.now();
                    var n = [];
                    t = c(t);
                    for (var r = t.next(); !r.done; r = t.next()) r = r.value, n.push({
                        timestamp: r.start,
                        type: "requestStart"
                    }), n.push({
                        timestamp: r.end,
                        type: "requestEnd"
                    });
                    t = c(e);
                    for (r = t.next(); !r.done; r = t.next()) n.push({
                        timestamp: r.value,
                        type: "requestStart"
                    });
                    n.sort(function(e, t) {
                        return e.timestamp - t.timestamp
                    });
                    e = e.length;
                    for (t = n.length - 1; 0 <= t; t--) switch (r = n[t], r.type) {
                        case "requestStart":
                            e--;
                            break;
                        case "requestEnd":
                            e++;
                            if (2 < e) return r.timestamp;
                            break;
                        default:
                            throw Error("Internal Error: This should never happen")
                    }
                    return 0
                }

                function b(e) {
                    e = e || {};
                    this.w = !!e.useMutationObserver;
                    this.u = e.minValue || null;
                    e = window.__tti && window.__tti.e;
                    var t = window.__tti && window.__tti.o;
                    this.a = e ? e.map(function(e) {
                        return {
                            start: e.startTime,
                            end: e.startTime + e.duration
                        }
                    }) : [];
                    t && t.disconnect();
                    this.b = [];
                    this.f = new Map;
                    this.j = null;
                    this.v = -1 / 0;
                    this.i = !1;
                    this.h = this.c = this.s = null;
                    f(this.m.bind(this), this.l.bind(this));
                    l(this.m.bind(this), this.l.bind(this));
                    g(this);
                    this.w && (this.h = m(this.B.bind(this)))
                }
                b.prototype.getFirstConsistentlyInteractive = function() {
                    var t = this;
                    return new Promise(function(e) {
                        t.s = e;
                        "complete" == document.readyState ? h(t) : window.addEventListener("load", function() {
                            h(t)
                        })
                    })
                };

                function h(e) {
                    e.i = !0;
                    var t = 0 < e.a.length ? e.a[e.a.length - 1].end : 0,
                        n = w(e.g, e.b);
                    y(e, Math.max(n + 5e3, t))
                }

                function y(i, e) {
                    !i.i || i.v > e || (clearTimeout(i.j), i.j = setTimeout(function() {
                        var e = performance.timing.navigationStart,
                            t = w(i.g, i.b),
                            e = (window.a && window.a.A ? 1e3 * window.a.A().C - e : 0) || performance.timing.domContentLoadedEventEnd - e;
                        if (i.u) var n = i.u;
                        else n = performance.timing.domContentLoadedEventEnd ? (n = performance.timing, n.domContentLoadedEventEnd - n.navigationStart) : null;
                        var r = performance.now();
                        null === n && y(i, Math.max(t + 5e3, r + 1e3));
                        var o = i.a;
                        t = 5e3 > r - t ? null : (t = o.length ? o[o.length - 1].end : e, 5e3 > r - t ? null : Math.max(t, n));
                        t && (i.s(t), clearTimeout(i.j), i.i = !1, i.c && i.c.disconnect(), i.h && i.h.disconnect());
                        y(i, performance.now() + 1e3)
                    }, e - performance.now()), i.v = e)
                }

                function g(r) {
                    r.c = new PerformanceObserver(function(e) {
                        e = c(e.getEntries());
                        for (var t = e.next(); !t.done; t = e.next())
                            if (t = t.value, "resource" === t.entryType && (r.b.push({
                                    start: t.fetchStart,
                                    end: t.responseEnd
                                }), y(r, w(r.g, r.b) + 5e3)), "longtask" === t.entryType) {
                                var n = t.startTime + t.duration;
                                r.a.push({
                                    start: t.startTime,
                                    end: n
                                });
                                y(r, n + 5e3)
                            }
                    });
                    r.c.observe({
                        entryTypes: ["longtask", "resource"]
                    })
                }
                b.prototype.m = function(e) {
                    this.f.set(e, performance.now())
                };
                b.prototype.l = function(e) {
                    this.f.delete(e)
                };
                b.prototype.B = function() {
                    y(this, performance.now() + 5e3)
                };
                t.Object.defineProperties(b.prototype, {
                    g: {
                        configurable: !0,
                        enumerable: !0,
                        get: function() {
                            return [].concat(s(this.f.values()))
                        }
                    }
                });
                var E = {
                    getFirstConsistentlyInteractive: function(e) {
                        e = e || {};
                        return "PerformanceLongTaskTiming" in window ? new b(e).getFirstConsistentlyInteractive() : Promise.resolve(null)
                    }
                };
                true, T.exports ? T.exports = E : (true, !(S = [], O = function() {
                    return E
                }.apply(j, S), void 0 !== O && (T.exports = O)))
            })()
        }).call(this, e("./node_modules/webpack/buildin/global.js"))
    },
    "./node_modules/webpack/buildin/global.js": function(e, t) {
        var n;
        n = function() {
            return this
        }();
        try {
            n = n || new Function("return this")()
        } catch (e) {
            "object" === typeof window && (n = window)
        }
        e.exports = n
    },
    "./src/main/webapp/frontend/packages/enums/PageTypes.js": function(e, t) {
        var n = {
            MAIN_CONTENT: 1,
            CONTENT_COLLECTION: 1,
            PAGE: 2,
            SPLASH_PAGE: 3,
            CONTENT_ITEM: 50,
            NOT_FOUND: 100,
            ERROR: 101,
            SEARCH: 102,
            LOCK_SCREEN: 103,
            POPUP_OVERLAY: 104,
            PROTECTED_CONTENT: 105,
            MEMBER_AREA_ACCESS_DENIED: 106,
            SHOW_CART: 200,
            CHECKOUT: 201,
            ORDER_CONFIRMED: 202,
            DONATE: 203,
            CONTRIBUTION_CONFIRMED: 204,
            COMMERCE_CART_V2: 205,
            SUBSCRIPTION_CONFIRMED: 206,
            ORDER_RECEIVED: 207,
            MEMBERSHIP_CONFIRMED: 208,
            NEWSLETTER_UNSUBSCRIBE: 300,
            COMMERCE_EMAIL_PREVIEW: 301
        };
        e.exports = n
    },
    "./src/main/webapp/frontend/packages/enums/StatusConstants.js": function(e, t) {
        var n = {
            EXPIRED: 1,
            PASTDUE: 2,
            TRIAL: 3,
            BETA: 4,
            REMOVED: 5,
            INTERNAL: 6,
            COMPED: 7,
            PAID: 8,
            V5_LINKED: 11,
            ACTIVE_PARKING_PAGE: 12,
            RESOLD: 13,
            RESOLD_GRACE_PERIOD: 14,
            ENTERPRISE: 15
        };
        e.exports = n
    },
    "./src/main/webapp/universal/src/apps/Performance/bootstrap.js": function(e, t, n) {
        "use strict";
        var r = n("./common/temp/node_modules/@babel/runtime/helpers/interopRequireDefault.js");
        var o = r(n("./common/temp/node_modules/@babel/runtime/helpers/defineProperty.js"));
        var i = r(n("./common/temp/node_modules/@sqs/rum-collector/lib/index.js"));
        var c = r(n("./src/main/webapp/frontend/packages/enums/StatusConstants.js"));
        var a = r(n("./src/main/webapp/frontend/packages/enums/PageTypes.js"));
        var s = n("./src/main/webapp/universal/src/shared/utils/error-reporter/global-sentry.ts");

        function u(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(t);
                e && (r = r.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                }));
                n.push.apply(n, r)
            }
            return n
        }

        function d(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? u(Object(n), true).forEach(function(e) {
                    (0, o.default)(t, e, n[e])
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                })
            }
            return t
        }
        var f = window.Static && window.Static.SQUARESPACE_CONTEXT;
        var l = window.top !== window;
        var p = Object.freeze((0, o.default)({}, a.default.COMMERCE_CART_V2, "commerce-cart"));

        function v() {
            var e = window.location && window.location.pathname || "";
            return !l && /^\/config(\/.*)?$/.test(e)
        }

        function m() {
            return {
                inFrame: l,
                templateId: f.templateId || "",
                impersonatedSession: !!f.impersonatedSession,
                pageType: "number" === typeof f.pageType ? f.pageType : -1
            }
        }

        function w() {
            var e = f.website,
                t = void 0 === e ? {} : e;
            return {
                authenticUrl: t.authenticUrl || "",
                cloneable: !!t.cloneable,
                developerMode: !!t.developerMode,
                isHstsEnabled: !!t.isHstsEnabled,
                language: t.language || "",
                timeZone: t.timeZone || "",
                websiteId: t.id || "",
                websiteType: t.websiteType || -1
            }
        }

        function b() {
            var e = f.websiteSettings,
                t = void 0 === e ? {} : e;
            return {
                ampEnabled: !!t.ampEnabled
            }
        }

        function h() {
            var e = f.collection,
                t = void 0 === e ? {} : e;
            return {
                collectionType: t.type || -1
            }
        }

        function y() {
            return window.Squarespace && "SECTION_CONTEXT" in window.Squarespace
        }

        function g() {
            if (f.hasOwnProperty("templateVersion")) return f.templateVersion.replace(".", "_");
            if (y()) return "8";
            return null
        }

        function E(e) {
            var t = v();
            var n = p[f.pageType];
            var r = {
                appName: n || "v".concat(e, "-").concat(t ? "config" : "user-sites"),
                context: d({}, m(), {}, w(), {}, b(), {}, h()),
                captureException: function e(t, n) {
                    (0, s.withScope)(function(e) {
                        e.setTag("project", "rum-collector");
                        void 0 !== n && e.setExtra("extras", n);
                        (0, s.captureException)(t)
                    })
                }
            };
            if (t) {
                var o = f.website.siteStatus.value === c.default.INTERNAL;
                var i = f.authenticatedAccount,
                    a = i.createdOn,
                    u = i.id;
                r.context.isInternal = o;
                r.context.createdOn = a;
                r.context.memberId = u
            }
            return r
        }

        function _() {
            if (true, f) {
                var e = g();
                if (null === e) return;
                var t = E(e);
                (0, i.default)(t)
            }
        }
        _()
    },
    "./src/main/webapp/universal/src/shared/utils/error-reporter/global-sentry.ts": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: true
        });
        t.isSentryConnected = t.withScope = t.configureScope = t.captureEvent = t.captureException = t.captureMessage = void 0;
        var r, o, i, a, u;
        t.withScope = u;
        t.configureScope = a;
        t.captureEvent = i;
        t.captureException = o;
        t.captureMessage = r;
        var c = function e(t) {
            var n;
            for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
            (n = console).log.apply(n, ["[Sentry] ".concat(t)].concat(o));
            return "some-error-identifier"
        };
        var s = false;
        t.isSentryConnected = s;
        if (window.SQUARESPACE_SENTRY) {
            t.isSentryConnected = s = true;
            t.captureMessage = r = window.SQUARESPACE_SENTRY.captureMessage;
            t.captureException = o = window.SQUARESPACE_SENTRY.captureException;
            t.captureEvent = i = window.SQUARESPACE_SENTRY.captureEvent;
            t.configureScope = a = window.SQUARESPACE_SENTRY.configureScope;
            t.withScope = u = window.SQUARESPACE_SENTRY.withScope
        } else {
            t.captureMessage = r = c;
            t.captureException = o = c;
            t.captureEvent = i = c;
            t.configureScope = a = function e() {};
            t.withScope = u = function e() {}
        }
    }
});
//# sourceMappingURL=https://sourcemaps.squarespace.net/universal/scripts-compressed/performance-ab14df3e45ccf3808dbc8-min.en-US.js.map