<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Footer</title>
    <!-- Stylesheets -->
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link
        href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&amp;family=Teko:wght@300;400;500;600;700&amp;display=swap"
        rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/owl.css" rel="stylesheet">
    <link href="css/flaticon.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/jquery-ui.css" rel="stylesheet">
    <link href="css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="css/hover.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jarallax.css">
    <link href="css/custom-animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- rtl css -->
    <link href="css/rtl.css" rel="stylesheet">
    <!-- Responsive File -->
    <link href="css/responsive.css" rel="stylesheet">

    <!-- Color css -->
    <link rel="stylesheet" id="jssDefault" href="css/colors/color-default.css">

    <link rel="shortcut icon" href="images/logo/logo.png" id="fav-shortcut" type="image/x-icon">
    <link rel="icon" href="images/logo/logo.png" id="fav-icon" type="image/x-icon">

    <!-- Responsive Settings -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

    <div class="page-wrapper">

    <!-- Main Footer -->
    <footer class="main-footer">
        <div class="auto-container">
            <!--Widgets Section-->
            <div class="widgets-section">
                <div class="row clearfix">

                    <!--Column-->
                    <div class="column col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-widget links-widget">
                            <div class="widget-content">
                                <h6>Web Development</h6>
                                <div class="row clearfix pl-3">
                                        <ul>
                                        <li><a href="ui-ux-designing-services-winnipeg.php">UI/UX Designing</a></li>
                                            <li><a href="web-development-services-winnipeg.php">Web Development</a></li>
                                            <li><a href="#">Wordpress Website</a></li>
                                            <li><a href="#">Ecommerce Website</a></li>
                                        </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Column-->
                    <div class="column col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-widget links-widget">
                            <div class="widget-content">
                                <h6>Social Media Marketing</h6>
                                <div class="row clearfix pl-3">
                                        <ul>
                                            <li><a href="influencers-and-pr-marketing-company-winnipeg.php">Infulencer & PR Marketing</a></li>
                                            <li><a href="instagram-marketing-company-winnipeg.php">Instagram Marketing</a></li>
                                            <li><a href="facebook-marketing-company-winnipeg.php">Facebook Marketing</a></li>
                                            <li><a href="youtube-marketing-company-winnipeg.php">Youtube Marketing</a></li>
                                        </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                    <div class="column col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-widget links-widget">
                            <div class="widget-content">
                                <h6>Search Engine Optimization</h6>
                                <div class="row clearfix pl-3">
                                        <ul>
                                        <li><a href="local-seo-services-winnipeg.php">Local Seo Services</a></li>
                                            <li><a href="seo-link-building-winnipeg.php">Link Building SEO Services</a></li>
                                            <li><a href="on-page-seo-winnipeg.php">On Page SEO Services</a></li>
                                            <li><a href="organic-seo-company-winnipeg.php">Organic SEO Services</a></li>
                                            <li><a href="content-marketing-services-winnipeg.php">SEO Content Writing</a></li>
                                        </ul>
                                
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--Column-->
                    <div class="column col-lg-3 col-md-6 col-sm-6" id="contact_details">
                        <div class="footer-widget links-widget">
                            <div class="widget-content">
                                <h6>Contact</h6>
                                <ul class="contact-info">
                                        <li class="address"><span class="icon flaticon-pin-1"></span>Winnipeg Manitoba, Canada</li>
                                        <li><span class="icon flaticon-call"></span><a href="tel:+1 (431) 688 4063">+1 (431) 688 4063</a></li>
                                        <li><span class="icon flaticon-email-2"></span><a
                                                href="mailto:info@nhconsultants.ca">info@nhconsultants.ca</a></li>
                                    </ul>
                                    <div class="text">Follow us on:</div>
                                    <ul class="social-links clearfix d-flex">
                                        <li><a href="#"><span class="fab fa-facebook-square"></span></a></li>
                                        <li><a href="#"><span class="fab fa-twitter"></span></a></li>
                                        <li><a href="#"><span class="fab fa-instagram"></span></a></li>
                                        <li><a href="#"><span class="fab fa-pinterest-p"></span></a></li>
                                    </ul>
                            </div>
                        </div>
                    </div>

                    

                </div>

            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="auto-container">
                <div class="inner clearfix">
                    <div class="copyright">&copy; copyright 2021 by NH Consultants</div>
                </div>
            </div>
        </div>

    </footer>

    </div>
    <!--End pagewrapper-->
    <!--End pagewrapper-->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>



    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/mixitup.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jQuery.style.switcher.min.js"></script>
    <script type="text/javascript" src="../../cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.2/js.cookie.min.js">
    </script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/custom-script.js"></script>

    <script src="js/lang.js"></script>
    <script src="../../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>
    <script src="js/color-switcher.js"></script>
</body>

</html>