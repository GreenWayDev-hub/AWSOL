<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Our Happy Clients | NH Consultants</title>
    <!-- Stylesheets -->
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link
        href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&amp;family=Teko:wght@300;400;500;600;700&amp;display=swap"
        rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/owl.css" rel="stylesheet">
    <link href="css/flaticon.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/jquery-ui.css" rel="stylesheet">
    <link href="css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="css/hover.css" rel="stylesheet">
    <link href="css/custom-animate.css" rel="stylesheet">
    <link rel="stylesheet" href="css/jarallax.css">
    <link href="css/style.css" rel="stylesheet">
    <!-- rtl css -->
    <link href="css/rtl.css" rel="stylesheet">
    <!-- Responsive File -->
    <link href="css/responsive.css" rel="stylesheet">

    <!-- Color css -->
    <link rel="stylesheet" id="jssDefault" href="css/colors/color-default.css">

    <link rel="shortcut icon" href="images/logo/logo.png" id="fav-shortcut" type="image/x-icon">
    <link rel="icon" href="images/logo/logo.png" id="fav-icon" type="image/x-icon">

    <!-- Responsive Settings -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

    <div class="page-wrapper">

        
        <!-- Preloader -->
        <div class="preloader">
            <div class="icon"></div>
        </div>

        <!-- Main Header -->
        <?php
            include 'header.php';
        ?>
        <!-- End Main Header -->

        <!--Mobile Menu-->
        <div class="side-menu__block">


            <div class="side-menu__block-overlay custom-cursor__overlay">
                <div class="cursor"></div>
                <div class="cursor-follower"></div>
            </div><!-- /.side-menu__block-overlay -->
            <div class="side-menu__block-inner ">
                <div class="side-menu__top justify-content-end">

                    <a href="#" class="side-menu__toggler side-menu__close-btn"><img src="images/icons/close-1-1.png"
                            alt=""></a>
                </div><!-- /.side-menu__top -->


                <!-- <nav class="mobile-nav__container">
                    content is loading via js
                </nav> -->
                <div class="side-menu__sep"></div><!-- /.side-menu__sep -->
                <div class="side-menu__content">
                    <p>Linoor is a premium Template for Digital Agencies, Start Ups, Small Business and a wide range of
                        other agencies.</p>
                    <p><a href="mailto:needhelp@linoor.com">needhelp@linoor.com</a> <br> <a href="tel:888-999-0000">888
                            999 0000</a></p>
                    <div class="side-menu__social">
                        <a href="#"><i class="fab fa-facebook-square"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-pinterest-p"></i></a>
                    </div>
                </div><!-- /.side-menu__content -->
            </div><!-- /.side-menu__block-inner -->
        </div><!-- /.side-menu__block -->

        <!--Search Popup-->
        <div class="search-popup">
            <div class="search-popup__overlay custom-cursor__overlay">
                <div class="cursor"></div>
                <div class="cursor-follower"></div>
            </div><!-- /.search-popup__overlay -->
            <div class="search-popup__inner">
                <form action="#" class="search-popup__form">
                    <input type="text" name="search" placeholder="Type here to Search....">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div><!-- /.search-popup__inner -->
        </div><!-- /.search-popup -->


        <section class="portfolio-details-header">
            <div class="auto-container clearfix">
                <h2 class="portfolio-details-header__title">filmore experience</h2>
                <!-- /.portfolio-details-header__title -->
                <div class="clearfix">
                    <div class="portfolio-details-header__image">
                        <img src="images/update-26-02-2021/resources/portfolio-d-3.jpg" alt="">
                    </div><!-- /.portfolio-details-header__image -->
                </div><!-- /.clearfix -->
                <div class="row flex-lg-row-reverse">
                    <div class="col-sm-12 col-md-6">
                        <div class="portfolio-details-header__main-text">
                            Lorem Ipsum is simply dummy text of the printing and type setting industry has been the
                            standard dummy.
                        </div><!-- /.portfolio-details-header__text -->
                    </div><!-- /.col-sm-12 col-md-6 -->
                    <div class="col-sm-12 col-md-6">
                        <div class="row">
                            <div class="col-sm-12 col-md-6">
                                <h3 class="portfolio-details-header__sub-heading">Project demands:</h3>
                                <!-- /.portfolio-details-header__sub-heading -->
                                <ul class="list-unstyled portfolio-details-header__list">
                                    <li>Website Designing</li>
                                    <li>Development</li>
                                    <li>Set Up Demo</li>
                                </ul><!-- /.list-unstyled -->
                                <h3 class="portfolio-details-header__sub-heading">
                                    Launched in 2021:
                                </h3><!-- /.portfolio-details-header__sub-heading -->
                                <a href="#" class="portfolio-details-header__link">View Website</a>
                            </div><!-- /.col-sm-12 -->
                            <div class="col-sm-12 col-md-6">
                                <h3 class="portfolio-details-header__sub-heading">Clients:</h3>
                                <!-- /.portfolio-details-header__sub-heading -->
                                <p class="portfolio-details-header__text">Jessica Brown</p>
                                <!-- /.portfolio-details-header__text -->
                                <h3 class="portfolio-details-header__sub-heading">Category:</h3>
                                <!-- /.portfolio-details-header__sub-heading -->
                                <div class="portfolio-details-header__links">
                                    <a href="#">Graphic</a>
                                    <a href="#">Illustration</a>
                                </div><!-- /.portfolio-details-header__links -->
                            </div><!-- /.col-sm-12 -->
                        </div><!-- /.row -->
                    </div><!-- /.col-sm-12 -->
                </div><!-- /.row -->
                <hr class="portfolio-details-header__separator">
            </div><!-- /.auto-container -->
        </section><!-- /.portfolio-details__header -->

        <section class="portfolio-details-info">
            <div class="auto-container">
                <div class="row flex-md-row-reverse">
                    <div class="col-md-6">
                        <div class="portfolio-details-info__image">
                            <img src="images/update-26-02-2021/resources/portfolio-d-3-1.jpg" alt="">
                        </div><!-- /.portfolio-details-info__image -->
                    </div><!-- /.col-md-6 -->
                    <div class="col-md-6 d-flex">
                        <div class="my-auto">
                            <div class="portfolio-details-info__content">
                                <h3 class="portfolio-details-info__title">Unique layouts</h3>
                                <p class="portfolio-details-info__text">Tincidunt elit magnis nulla facilisis sagittis
                                    sapien in nunc amet ultrices dolores sit ipsum velit quet massa fringilla leo orci
                                    met
                                    ultrices, dolores sit ipsum velit massa fringilla leo.</p>
                                <!-- /.portfolio-details-info__text -->
                            </div><!-- /.portfolio-details-info__content -->
                        </div><!-- /.my-auto -->
                    </div><!-- /.col-md-6 -->
                </div><!-- /.row -->
                <div class="row flex-md-row-reverse">
                    <div class="col-md-6">
                        <div class="portfolio-details-info__image">
                            <img src="images/update-26-02-2021/resources/portfolio-d-3-2.jpg" alt="">
                        </div><!-- /.portfolio-details-info__image -->
                    </div><!-- /.col-md-6 -->
                    <div class="col-md-6 d-flex">
                        <div class="my-auto">
                            <div class="portfolio-details-info__content">
                                <h3 class="portfolio-details-info__title">easy customization</h3>
                                <p class="portfolio-details-info__text">Tincidunt elit magnis nulla facilisis sagittis
                                    sapien in nunc amet ultrices dolores sit ipsum velit quet massa fringilla leo orci
                                    met
                                    ultrices, dolores sit ipsum velit massa fringilla leo.</p>
                                <!-- /.portfolio-details-info__text -->
                            </div><!-- /.portfolio-details-info__content -->
                        </div><!-- /.my-auto -->
                    </div><!-- /.col-md-6 -->
                </div><!-- /.row -->
                <div class="row flex-md-row-reverse">
                    <div class="col-md-6">
                        <div class="portfolio-details-info__image">
                            <img src="images/update-26-02-2021/resources/portfolio-d-3-3.jpg" alt="">
                        </div><!-- /.portfolio-details-info__image -->
                    </div><!-- /.col-md-6 -->
                    <div class="col-md-6 d-flex">
                        <div class="my-auto">
                            <div class="portfolio-details-info__content">
                                <h3 class="portfolio-details-info__title">Project benefits</h3>
                                <p class="portfolio-details-info__text">Tincidunt elit magnis nulla facilisis sagittis
                                    sapien in nunc amet ultrices dolores sit ipsum velit quet massa fringilla leo orci
                                    met
                                    ultrices, dolores sit ipsum velit massa fringilla leo.</p>
                                <!-- /.portfolio-details-info__text -->
                            </div><!-- /.portfolio-details-info__content -->
                        </div><!-- /.my-auto -->
                    </div><!-- /.col-md-6 -->
                </div><!-- /.row -->
            </div><!-- /.auto-container -->
        </section><!-- /.portfolio-details-info -->


        <section class="portfolio-details-video">
            <div class="auto-container">
                <div class="portfolio-details-video__thumbnail">
                    <img src="images/update-26-02-2021/resources/portfolio-d-video-1.jpg" alt="">
                    <div class="vid-link">
                        <a href="https://www.youtube.com/watch?v=Get7rqXYrbQ" class="lightbox-image">
                            <div class="icon"><span class="flaticon-play-button-1"></span><i class="ripple"></i></div>
                        </a>
                    </div><!-- /.vid-link -->
                </div><!-- /.portfolio-details-video__thumbnail -->
            </div><!-- /.auto-container -->
        </section><!-- /.portfolio-details-video -->

        <section class="portfolio-details-summery">
            <div class="auto-container">
                <div class="row">
                    <div class="col-md-6">
                        <h3 class="portfolio-details-summery__heading">Conclusion</h3>
                        <!-- /.portfolio-details-summery__heading -->
                        <p class="portfolio-details-summery__text">
                            Tincidunt elit magnis nulla facilisis sagittis sapien in nunc amet ultrices dolores sit
                            ipsum velit quet massa fringilla leo orci nc amet ultrices, dolores sit ipsum velit massa
                            fringilla leo.
                        </p><!-- /.portfolio-details-summery__text -->
                    </div><!-- /.col-md-6 -->
                    <div class="col-md-6">
                        <h3 class="portfolio-details-summery__heading">result</h3>
                        <!-- /.portfolio-details-summery__heading -->
                        <p class="portfolio-details-summery__text">
                            Tincidunt elit magnis nulla facilisis sagittis sapien in nunc amet ultrices dolores sit
                            ipsum velit quet massa fringilla leo orci nc amet ultrices, dolores sit ipsum velit massa
                            fringilla leo.
                        </p><!-- /.portfolio-details-summery__text -->
                    </div><!-- /.col-md-6 -->
                </div><!-- /.row -->
            </div><!-- /.auto-container -->
        </section><!-- /.portfolio-details-summery -->



        <div class="post-control">
            <div class="auto-container">
                <div class="inner clearfix">
                    <div class="control prev"><a href="#"><span class="fa fa-angle-left"></span> &nbsp; Previous</a>
                    </div>
                    <div class="control next"><a href="#">Next &nbsp;<span class="fa fa-angle-right"></span></a></div>
                </div>
            </div>
        </div>

        <!-- Similar Section -->
        <section class="gallery-section similar-gallery">
            <div class="auto-container">
                <div class="sec-title centered">
                    <h2>Similar work<span class="dot">.</span></h2>
                </div>
                <div class="row clearfix">
                    <!-- Gallery Item -->
                    <div class="gallery-item col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <figure class="image"><img src="images/gallery/4.jpg" alt=""></figure>
                            <a href="images/gallery/4.jpg" class="lightbox-image overlay-box"
                                data-fancybox="gallery"></a>
                            <div class="cap-box">
                                <div class="cap-inner">
                                    <div class="cat"><span>Graphic</span></div>
                                    <div class="title">
                                        <h5><a href="portfolio-single.html">Fimlor Experience</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Gallery Item -->
                    <div class="gallery-item col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <figure class="image"><img src="images/gallery/5.jpg" alt=""></figure>
                            <a href="images/gallery/5.jpg" class="lightbox-image overlay-box"
                                data-fancybox="gallery"></a>
                            <div class="cap-box">
                                <div class="cap-inner">
                                    <div class="cat"><span>Graphic</span></div>
                                    <div class="title">
                                        <h5><a href="portfolio-single.html">Fimlor Experience</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Gallery Item -->
                    <div class="gallery-item col-lg-4 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <figure class="image"><img src="images/gallery/6.jpg" alt=""></figure>
                            <a href="images/gallery/6.jpg" class="lightbox-image overlay-box"
                                data-fancybox="gallery"></a>
                            <div class="cap-box">
                                <div class="cap-inner">
                                    <div class="cat"><span>Graphic</span></div>
                                    <div class="title">
                                        <h5><a href="portfolio-single.html">Fimlor Experience</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section>




        <!-- Main Footer -->
        <?php
        include 'footer.php';
        ?>
    </div>
    <!--End pagewrapper-->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>



    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/mixitup.js"></script>
    <script src="js/knob.js"></script>
    <script src="js/validate.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jQuery.style.switcher.min.js"></script>
    <script type="text/javascript" src="../../cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.2/js.cookie.min.js">
    </script>
    <script src="js/jarallax.min.js"></script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/custom-script.js"></script>


    <script src="js/lang.js"></script>
    <script src="../../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>
    <script src="js/color-switcher.js"></script>

</body>

</html>