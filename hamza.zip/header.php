<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Header | NH Consultants</title>
    <!-- Stylesheets -->
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link
        href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&amp;family=Teko:wght@300;400;500;600;700&amp;display=swap"
        rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/fontawesome-all.css" rel="stylesheet">
    <link href="css/owl.css" rel="stylesheet">
    <link href="css/flaticon.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/jquery-ui.css" rel="stylesheet">
    <link href="css/jquery.fancybox.min.css" rel="stylesheet">
    <link href="css/hover.css" rel="stylesheet">
    <link href="css/custom-animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- rtl css -->
    <link href="css/rtl.css" rel="stylesheet">
    <!-- Responsive File -->
    <link href="css/responsive.css" rel="stylesheet">

    <!-- Color css -->
    <link rel="stylesheet" id="jssDefault" href="css/colors/color-default.css">

    <link rel="shortcut icon" href="images/logo/logo.png" id="fav-shortcut" type="image/x-icon">
    <link rel="icon" href="images/logo/logo.png" id="fav-icon" type="image/x-icon">

    <!-- Responsive Settings -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!--[if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script><![endif]-->
    <!--[if lt IE 9]><script src="js/respond.js"></script><![endif]-->
</head>

<body>

    <!-- <div class="page-wrapper">

        
        
        <div class="preloader">
            <div class="icon"></div>
        </div> -->

        <!-- Main Header -->
        <header class="main-header header-style-one">

            <!-- Header Upper -->
            <div class="header-upper">
                <div class="inner-container clearfix">
                    <!--Logo-->
                    <div class="logo-box">
                        <div class="logo"><a href="index.php" title="NH Consultants - Web Development Agency Winnipeg"><img
                                    src="images/logo/logo.png" id="thm-logo" alt="NH CONSULTANTS"
                                    title="NH CONSULTANTS"></a></div>
                    </div>
                    <div class="nav-outer clearfix">
                        <!--Mobile Navigation Toggler-->
                        <div class="mobile-nav-toggler"><span class="icon flaticon-menu-2"></span><span
                                class="txt">Menu</span></div>

                        <!-- Main Menu -->
                        <nav class="main-menu navbar-expand-md navbar-light">
                            <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                <ul class="navigation clearfix">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About us</a></li>
                                    <li class="dropdown"><a href="#">Web Development</a>
                                        <ul>
                                            <li><a href="ui-ux-designing-services-winnipeg.php">UI/UX Designing</a></li>
                                            <li><a href="web-development-services-winnipeg.php">Web Development</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">Social Media Marketing</a>
                                        <ul>
                                            <li><a href="influencers-and-pr-marketing-company-winnipeg.php">Influencer & PR Marketing</a></li>
                                            <li><a href="instagram-marketing-company-winnipeg.php">Instagram Marketing</a></li>
                                            <li><a href="facebook-marketing-company-winnipeg.php">Facebook Marketing</a></li>
                                            <li><a href="youtube-marketing-company-winnipeg.php">Youtube Marketing</a></li>
                                        </ul>
                                    </li>
                                    <li class="dropdown"><a href="#">Search Engine Optimization</a>
                                        <ul>
                                            <li><a href="local-seo-services-winnipeg.php">Local Seo Services</a></li>
                                            <li><a href="seo-link-building-winnipeg.php">Link Building Services</a></li>
                                            <li><a href="on-page-seo-winnipeg.php">On-Page SEO Services</a></li>
                                            <li><a href="organic-seo-company-winnipeg.php">Organic SEO Services</a></li>
                                            <li><a href="ecommerce-seo-services-winnipeg.php">Ecommerce SEO</a></li>
                                            <li><a href="ppc-campaigns-services-winnipeg.php">Pay Per Click Marketing</a></li>
                                            <li><a href="content-marketing-services-winnipeg.php">SEO Content Writing</a></li>
                                        </ul>
                                    </li>
                                    
                                    <li><a href="contact.php">Contact Now</a></li>
                                </ul>
                            </div>
                        </nav>
                    </div>

                    <div class="other-links clearfix">
                        
                        
                        <div class="link-box">
                            <div class="call-us">
                                <a class="link" href="+1 (431) 688 4063">
                                    <span class="icon"></span>
                                    <span class="sub-text">Call Anytime</span>
                                    <span class="number">+1 (431) 688 4063</span>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--End Header Upper-->

        </header>

        <!-- <div class="pay-top-pic">
            <img class="img-fluid w-100" width="100%" src="images/service-curve-top.jpg" alt="">
        </div> -->
        
    <!-- </div> -->
    <!--End pagewrapper-->

    <a href="#" data-target="html" class="scroll-to-target scroll-to-top"><i class="fa fa-angle-up"></i></a>



    <script src="js/jquery.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/TweenMax.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.fancybox.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/mixitup.js"></script>
    <script src="js/knob.js"></script>
    <script src="js/appear.js"></script>
    <script src="js/wow.js"></script>
    <script src="js/jQuery.style.switcher.min.js"></script>
    <script type="text/javascript" src="../../cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.2/js.cookie.min.js">
    </script>
    <script src="js/jquery.easing.min.js"></script>
    <script src="js/custom-script.js"></script>

    <script src="js/lang.js"></script>
    <script src="../../translate.google.com/translate_a/elementa0d8.html?cb=googleTranslateElementInit"></script>
    <script src="js/color-switcher.js"></script>

</body>
</html>